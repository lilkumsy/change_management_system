import React from 'react';
import { ChangeRequest } from '../types';
import { ClockIcon, UserCircleIcon } from '@heroicons/react/24/outline';

const AuditLog: React.FC<{ crs: ChangeRequest[] }> = ({ crs }) => {
  const allLogs = crs.flatMap(cr => cr.auditLogs.map(log => ({ ...log, crId: cr.id })))
    .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());

  return (
    <div className="space-y-6 text-black">
      <header className="flex justify-between items-end">
        <div>
          <h2 className="text-3xl font-bold">Enterprise Audit Trail</h2>
          <p className="text-black/60 font-medium">Immutable history of all core banking change actions.</p>
        </div>
        <button className="bg-white border border-slate-300 px-4 py-2 rounded-xl text-sm font-bold text-black hover:bg-slate-50 transition-colors">
          Export full CSV
        </button>
      </header>

      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead className="bg-slate-50 border-b">
              <tr className="text-[11px] uppercase font-black text-black/40 tracking-widest">
                <th className="px-6 py-4">Timestamp</th>
                <th className="px-6 py-4">Actor</th>
                <th className="px-6 py-4">Change ID</th>
                <th className="px-6 py-4">Action</th>
                <th className="px-6 py-4">Details</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {allLogs.map(log => (
                <tr key={log.id} className="hover:bg-slate-50/50 transition-colors">
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2 text-xs font-mono text-black/70 font-bold">
                      <ClockIcon className="w-3 h-3" />
                      {new Date(log.timestamp).toLocaleString()}
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2">
                      <UserCircleIcon className="w-5 h-5 text-black/20" />
                      <span className="text-sm font-bold text-black">{log.user}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <span className="px-2 py-0.5 bg-slate-100 rounded-md text-[10px] font-bold text-black/70">
                      {log.crId}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <span className="text-sm font-bold text-black">{log.action}</span>
                  </td>
                  <td className="px-6 py-4">
                    <p className="text-sm text-black/60 line-clamp-1 italic font-medium">{log.details}</p>
                  </td>
                </tr>
              ))}
              {allLogs.length === 0 && (
                <tr>
                  <td colSpan={5} className="text-center py-20 text-black/30 font-bold">No logs found.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default AuditLog;