
import React from 'react';
import { 
  CheckBadgeIcon,
  XMarkIcon,
  PrinterIcon,
  ShieldCheckIcon,
  CommandLineIcon,
  FingerPrintIcon,
  CalendarDaysIcon,
  DocumentTextIcon
} from '@heroicons/react/24/outline';
import { ChangeRequest, User } from '../types';

interface AuditCertificateProps {
  cr: ChangeRequest;
  allUsers: User[];
  onClose: () => void;
}

const AuditCertificate: React.FC<AuditCertificateProps> = ({ cr, allUsers, onClose }) => {
  const formatDate = (dateStr?: string) => {
    if (!dateStr) return 'N/A';
    return new Date(dateStr).toLocaleDateString('en-GB', { 
      day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' 
    });
  };

  const getUserSignature = (name?: string) => {
    if (!name) return null;
    return allUsers.find(u => u.name === name)?.signature;
  };

  const getTesterNames = () => {
    const ids = Array.from(new Set(cr.features.map(f => f.assignedTesterId)));
    return ids.map(id => allUsers.find(u => u.id === id)?.name || id);
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-md z-[100] flex items-center justify-center p-4 md:p-6 overflow-y-auto print:p-0 print:static print:bg-white">
      <div className="bg-white w-full max-w-5xl rounded-[2.5rem] shadow-2xl overflow-hidden flex flex-col max-h-[95vh] border border-slate-200 print:shadow-none print:border-none print:max-h-none print:static print:w-full print:rounded-none">
        
        {/* Navigation / Actions - Hidden on print */}
        <div className="px-8 py-5 bg-white border-b border-slate-100 flex justify-between items-center sticky top-0 z-20 no-print">
           <div className="flex items-center gap-4">
              <div className="w-8 h-8 bg-brand-orange rounded-xl flex items-center justify-center text-white text-lg font-black">N</div>
              <div className="h-5 w-px bg-slate-200"></div>
              <span className="text-[11px] font-black uppercase tracking-[0.25em] text-slate-400 leading-none">Certification Engine / v2.7</span>
           </div>
           <div className="flex items-center gap-4">
             <button 
                onClick={handlePrint}
                className="flex items-center gap-2 bg-brand-orange text-white px-6 py-3 rounded-2xl text-[10px] font-black uppercase tracking-widest hover:bg-black transition-all shadow-xl shadow-brand-orange/20 active:scale-95"
             >
               <PrinterIcon className="w-4 h-4" /> Download Certificate (PDF)
             </button>
             <button 
                onClick={onClose}
                className="p-3 bg-slate-50 border border-slate-100 rounded-2xl text-slate-400 hover:text-black hover:bg-slate-200 transition-all"
             >
               <XMarkIcon className="w-5 h-5" />
             </button>
           </div>
        </div>

        <div id="printable-certificate" className="flex-grow overflow-y-auto p-12 md:p-16 bg-white custom-scrollbar print:p-0 print:overflow-visible print:block">
           
           {/* Document Header */}
           <div className="flex justify-between items-start mb-10 pb-10 border-b-2 border-slate-100">
              <div className="space-y-2">
                 <h1 className="text-4xl font-black uppercase tracking-tight text-black">Change Certificate</h1>
                 <p className="text-slate-400 font-bold text-xs uppercase tracking-[0.2em]">NORRENBERGER PENSIONS: Official Production Release Record</p>
                 <div className="flex items-center gap-3 mt-5">
                    <div className="flex items-center gap-2 text-[9px] font-black text-slate-500 uppercase bg-slate-50 px-3 py-1.5 rounded-lg border border-slate-100">
                       <FingerPrintIcon className="w-3.5 h-3.5" /> Immutable Hash
                    </div>
                    <div className="flex items-center gap-2 text-[9px] font-black text-slate-500 uppercase bg-slate-50 px-3 py-1.5 rounded-lg border border-slate-100">
                       <CalendarDaysIcon className="w-3.5 h-3.5" /> {formatDate(cr.deployedAt || new Date().toISOString())}
                    </div>
                 </div>
              </div>
              <div className="text-right">
                 <div className="px-5 py-4 bg-slate-50 border border-slate-100 rounded-2xl text-left inline-block">
                    <p className="text-[8px] font-black text-slate-400 uppercase tracking-[0.2em] mb-1">Control ID</p>
                    <p className="text-xl font-mono font-black text-black leading-none">{cr.id}</p>
                 </div>
              </div>
           </div>

           {/* Metadata Summary */}
           <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-10">
              <div className="px-5 py-4 rounded-2xl bg-slate-50/50 border border-slate-100">
                 <p className="text-[8px] font-black text-slate-400 uppercase mb-1">Project Registry</p>
                 <p className="text-xs font-black text-black line-clamp-1">{cr.title}</p>
              </div>
              <div className="px-5 py-4 rounded-2xl bg-slate-50/50 border border-slate-100">
                 <p className="text-[8px] font-black text-slate-400 uppercase mb-1">Vendor/Version</p>
                 <p className="text-xs font-black text-black line-clamp-1">{cr.vendorName} {cr.versionNumber}</p>
              </div>
              <div className="px-5 py-4 rounded-2xl bg-slate-50/50 border border-slate-100">
                 <p className="text-[8px] font-black text-slate-400 uppercase mb-1">Environment</p>
                 <p className="text-xs font-black text-brand-orange uppercase">{cr.environment}</p>
              </div>
              <div className="px-5 py-4 rounded-2xl bg-slate-50/50 border border-slate-100">
                 <p className="text-[8px] font-black text-slate-400 uppercase mb-1">Lead Architect</p>
                 <p className="text-xs font-black text-black line-clamp-1">{cr.createdBy}</p>
              </div>
           </div>

           {/* Lifecycle Phases */}
           <div className="space-y-8">
              
              {/* PHASE I: TECHNICAL */}
              <div className="border-2 border-slate-100 rounded-[2rem] p-8 bg-white">
                 <div className="flex items-center gap-4 mb-6">
                    <div className="w-10 h-10 rounded-xl bg-orange-50 flex items-center justify-center text-brand-orange border border-orange-100">
                       <DocumentTextIcon className="w-5 h-5" />
                    </div>
                    <div>
                       <h4 className="text-sm font-black uppercase tracking-tight text-black">Phase I: Technical Validation</h4>
                       <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mt-1">UAT Outcome Certification</p>
                    </div>
                 </div>

                 <div className="overflow-hidden border border-slate-100 rounded-2xl mb-6">
                    <table className="w-full text-left">
                       <thead className="bg-slate-50">
                          <tr className="text-[8px] uppercase font-black text-slate-400 tracking-[0.2em] border-b border-slate-100">
                             <th className="px-6 py-3">Component</th>
                             <th className="px-6 py-3 text-center">Status</th>
                             <th className="px-6 py-3">Audit Observations</th>
                          </tr>
                       </thead>
                       <tbody className="divide-y divide-slate-100">
                          {cr.features.map(f => (
                             <tr key={f.id} className="text-xs">
                                <td className="px-6 py-4 font-black text-black">{f.name}</td>
                                <td className="px-6 py-4 text-center">
                                   <span className={`text-[9px] font-black px-2 py-0.5 rounded-lg uppercase border ${f.testResult === 'Pass' ? 'bg-emerald-50 text-emerald-600 border-emerald-100' : 'bg-red-50 text-red-600 border-red-100'}`}>
                                      {f.testResult}
                                   </span>
                                </td>
                                <td className="px-6 py-4 text-slate-500 italic leading-relaxed text-[11px]">
                                   "{f.testObservations || 'Validated against functional requirements.'}"
                                </td>
                             </tr>
                          ))}
                       </tbody>
                    </table>
                 </div>

                 <div className="flex flex-wrap gap-3">
                    {getTesterNames().map((name, i) => (
                       <div key={i} className="flex items-center gap-4 py-2 px-4 bg-slate-50 rounded-2xl border border-slate-100">
                          <div className="text-left">
                             <p className="text-[10px] font-black text-black uppercase">{name}</p>
                             <p className="text-[8px] text-slate-400 font-bold uppercase tracking-tighter">Certified Tester</p>
                          </div>
                          <div className="h-8 w-20 bg-white rounded-lg flex items-center justify-center border border-slate-200 overflow-hidden">
                             {getUserSignature(name) ? (
                                <img src={getUserSignature(name)!} alt="Seal" className="h-full object-contain mix-blend-multiply opacity-50" />
                             ) : (
                                <span className="font-serif italic text-slate-200 text-[8px]">Pending</span>
                             )}
                          </div>
                       </div>
                    ))}
                 </div>
              </div>

              {/* PHASE II & III: GRID */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                 
                 {/* Enterprise Risk (Phase II) */}
                 <div className="border-2 border-slate-100 rounded-[2rem] p-8 bg-white flex flex-col">
                    <div className="flex items-center gap-4 mb-6">
                       <div className="w-10 h-10 rounded-xl bg-slate-50 flex items-center justify-center text-slate-500 border border-slate-200">
                          <ShieldCheckIcon className="w-5 h-5" />
                       </div>
                       <div>
                          <h4 className="text-sm font-black uppercase tracking-tight text-black">Phase II: Risk Governance</h4>
                          <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mt-1">Independent Assurance</p>
                       </div>
                    </div>
                    
                    <div className="p-5 bg-slate-50 rounded-2xl border border-slate-100 flex-grow mb-6">
                       <div className="flex justify-between items-center mb-3 pb-2 border-b border-slate-200/50">
                          <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Decision</p>
                          <span className="text-[11px] font-black text-brand-orange uppercase">{cr.riskAssessment?.decision || 'Accepted'}</span>
                       </div>
                       <p className="text-xs text-slate-600 font-medium italic leading-relaxed">
                          "{cr.riskAssessment?.comments || 'Change risk profile aligns with corporate risk appetite.'}"
                       </p>
                    </div>

                    <div className="flex items-center justify-between pt-4 border-t border-slate-100">
                       <div>
                          <p className="text-sm font-black text-black uppercase leading-none">{cr.riskAssessment?.assessedBy || 'N/A'}</p>
                          <p className="text-[9px] text-slate-400 font-bold uppercase tracking-tighter mt-1.5">Enterprise Risk Manager</p>
                       </div>
                       <div className="h-10 w-28 bg-slate-50 rounded-xl flex items-center justify-center border border-slate-200 overflow-hidden px-2">
                          {getUserSignature(cr.riskAssessment?.assessedBy) ? (
                             <img src={getUserSignature(cr.riskAssessment?.assessedBy)!} alt="Seal" className="h-full object-contain mix-blend-multiply opacity-70" />
                          ) : (
                             <span className="font-serif italic text-slate-300 text-[10px]">Registry Seal</span>
                          )}
                       </div>
                    </div>
                 </div>

                 {/* Executive Authorization (Phase III) */}
                 <div className="border-2 border-slate-200 rounded-[2rem] p-8 bg-slate-50/20 flex flex-col">
                    <div className="flex items-center gap-4 mb-6">
                       <div className="w-10 h-10 rounded-xl bg-white flex items-center justify-center text-brand-navy border border-slate-200">
                          <CheckBadgeIcon className="w-5 h-5" />
                       </div>
                       <div>
                          <h4 className="text-sm font-black uppercase tracking-tight text-black">Phase III: Authorization</h4>
                          <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mt-1">Management Oversight</p>
                       </div>
                    </div>

                    <div className="p-5 bg-white rounded-2xl border border-slate-200/60 flex-grow mb-6">
                       <div className="flex justify-between items-center mb-3 pb-2 border-b border-slate-100">
                          <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Executive Status</p>
                          <span className="text-[11px] font-black text-emerald-600 uppercase">Authorized</span>
                       </div>
                       <p className="text-xs text-slate-600 font-medium italic leading-relaxed">
                          "{cr.itApproval?.comments || 'Migration authorized for production execution window.'}"
                       </p>
                    </div>

                    <div className="flex items-center justify-between pt-4 border-t border-slate-200/60">
                       <div>
                          <p className="text-sm font-black text-black uppercase leading-none">{cr.itApproval?.approvedBy || 'N/A'}</p>
                          <p className="text-[9px] text-slate-400 font-bold uppercase tracking-tighter mt-1.5">Head of ICT Operations</p>
                       </div>
                       <div className="h-10 w-28 bg-white rounded-xl flex items-center justify-center border border-slate-200 overflow-hidden px-2">
                          {getUserSignature(cr.itApproval?.approvedBy) ? (
                             <img src={getUserSignature(cr.itApproval?.approvedBy)!} alt="Seal" className="h-full object-contain mix-blend-multiply opacity-80" />
                          ) : (
                             <span className="font-serif italic text-slate-300 text-[10px]">Registry Seal</span>
                          )}
                       </div>
                    </div>
                 </div>
              </div>

              {/* PHASE IV: EXECUTION */}
              <div className="border-2 border-slate-200 rounded-[2rem] p-8 flex items-center justify-between gap-10 bg-white shadow-sm">
                 <div className="flex items-center gap-5">
                    <div className="w-12 h-12 rounded-2xl bg-orange-50 flex items-center justify-center text-brand-orange border border-orange-100">
                       <CommandLineIcon className="w-6 h-6" />
                    </div>
                    <div>
                       <h4 className="text-base font-black uppercase tracking-tight text-black leading-none">Phase IV: Execution Certification</h4>
                       <p className="text-[10px] text-slate-400 font-black uppercase tracking-widest mt-2">Production Deployment Completed successfully</p>
                    </div>
                 </div>
                 
                 <div className="flex items-center gap-8">
                    <div className="text-right">
                       <p className="text-sm font-black text-black leading-none">{cr.deployedBy || 'N/A'}</p>
                       <p className="text-[9px] text-slate-400 font-bold uppercase tracking-widest mt-1.5">Systems Engineer</p>
                    </div>
                    <div className="h-12 w-32 bg-slate-50 rounded-2xl flex items-center justify-center border border-slate-200 overflow-hidden px-4">
                       {getUserSignature(cr.deployedBy) ? (
                          <img src={getUserSignature(cr.deployedBy)!} alt="Seal" className="h-full object-contain mix-blend-multiply opacity-90" />
                       ) : (
                          <span className="font-serif italic text-slate-300 text-[10px]">Confirmed</span>
                       )}
                    </div>
                 </div>
              </div>
           </div>

           {/* Compact & Justified Footer Certification */}
           <div className="mt-12 pt-8 border-t border-slate-100 flex flex-col items-center gap-3">
              <div className="w-full px-8 py-4 bg-slate-50 border border-slate-100 rounded-2xl">
                 <p className="text-[10px] font-black text-black/60 uppercase tracking-widest leading-loose text-justify">
                    Certified Record: This document is an immutable record of technical compliance and governance. All digital signatures are binding attestations verified against the corporate change registry. This record serves as primary evidence for audit trail and regulatory compliance under enterprise technical governance framework.
                 </p>
              </div>
              <div className="flex items-center gap-5 opacity-40">
                 <p className="text-[7px] font-mono text-slate-400 uppercase tracking-[0.3em]">Hash: {Math.random().toString(36).substr(2, 32).toUpperCase()}</p>
                 <div className="w-1.5 h-1.5 rounded-full bg-slate-300"></div>
                 <p className="text-[7px] font-mono text-slate-400 uppercase tracking-[0.3em]">End of Audit Trace</p>
              </div>
           </div>

        </div>
      </div>
      
      <style>{`
        @media print {
          /* 1. Global Print Resets */
          body { 
            margin: 0 !important; 
            padding: 0 !important; 
            background: white !important; 
          }
          
          /* 2. Hide all common UI elements by class or tag */
          .no-print, header, aside, nav, button, .no-print-background {
            display: none !important;
          }

          /* 3. Ensure the Modal Container fills the screen for printing */
          .fixed.inset-0 {
            position: absolute !important;
            top: 0 !important;
            left: 0 !important;
            width: 100% !important;
            height: auto !important;
            background: white !important;
            backdrop-filter: none !important;
            display: block !important;
            padding: 0 !important;
            margin: 0 !important;
            z-index: 9999 !important;
            overflow: visible !important;
          }

          /* 4. Reset the Certificate Content Card */
          .bg-white.w-full.max-w-5xl {
            max-width: 100% !important;
            width: 100% !important;
            margin: 0 !important;
            border: none !important;
            box-shadow: none !important;
            border-radius: 0 !important;
            max-height: none !important;
            overflow: visible !important;
          }

          /* 5. Force the internal content to expand */
          #printable-certificate {
            padding: 40px !important;
            width: 100% !important;
            display: block !important;
            overflow: visible !important;
          }

          /* 6. Page setup */
          @page {
            size: A4;
            margin: 10mm;
          }

          /* 7. Force high quality rendering */
          * {
            -webkit-print-color-adjust: exact !important;
            print-color-adjust: exact !important;
          }
        }
      `}</style>
    </div>
  );
};

export default AuditCertificate;
