
import React, { useState, useMemo } from 'react';
import { 
  CalendarIcon, 
  DocumentChartBarIcon,
  DocumentArrowDownIcon,
  MagnifyingGlassIcon,
  ArchiveBoxXMarkIcon
} from '@heroicons/react/24/outline';
import { ChangeRequest, User, CRStatus } from '../types';
import AuditCertificate from './AuditCertificate';

interface ReportsPortalProps {
  crs: ChangeRequest[];
  allUsers: User[];
  currentUser: User;
}

const ReportsPortal: React.FC<ReportsPortalProps> = ({ crs, allUsers, currentUser }) => {
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [selectedCr, setSelectedCr] = useState<ChangeRequest | null>(null);

  // Only consider deployed or failed deployments for this report
  const filteredCrs = useMemo(() => {
    return crs.filter(cr => {
      if (cr.status !== CRStatus.DEPLOYED && cr.status !== CRStatus.DEPLOYMENT_FAILED) return false;
      if (!cr.deployedAt) return false;

      const deployDate = new Date(cr.deployedAt);
      deployDate.setHours(0, 0, 0, 0);

      if (startDate) {
        const start = new Date(startDate);
        start.setHours(0, 0, 0, 0);
        if (deployDate < start) return false;
      }

      if (endDate) {
        const end = new Date(endDate);
        end.setHours(23, 59, 59, 999);
        if (deployDate > end) return false;
      }

      return true;
    }).sort((a, b) => new Date(b.deployedAt!).getTime() - new Date(a.deployedAt!).getTime());
  }, [crs, startDate, endDate]);

  const formatDate = (dateStr?: string) => {
    if (!dateStr) return 'N/A';
    return new Date(dateStr).toLocaleDateString('en-GB', { 
      day: '2-digit', month: 'short', year: 'numeric'
    });
  };

  return (
    <div className="space-y-8 animate-fadeIn text-black">
      <header className="border-b pb-6 border-orange-100 flex justify-between items-end">
        <div>
          <h2 className="text-3xl font-bold">Deployment Intelligence</h2>
          <p className="text-black/60 font-medium italic">Advanced reporting for production migration history.</p>
        </div>
        <div className="flex items-center gap-4 bg-white p-3 rounded-2xl border border-slate-200 shadow-sm">
           <div className="flex flex-col">
              <label className="text-[9px] font-black text-black/40 uppercase ml-1">Start Date</label>
              <input 
                type="date" 
                className="text-xs font-bold border-0 bg-transparent outline-none" 
                value={startDate} 
                onChange={e => setStartDate(e.target.value)}
              />
           </div>
           <div className="w-px h-8 bg-slate-100"></div>
           <div className="flex flex-col">
              <label className="text-[9px] font-black text-black/40 uppercase ml-1">End Date</label>
              <input 
                type="date" 
                className="text-xs font-bold border-0 bg-transparent outline-none" 
                value={endDate} 
                onChange={e => setEndDate(e.target.value)}
              />
           </div>
           <button 
            onClick={() => { setStartDate(''); setEndDate(''); }}
            className="p-2 text-black/20 hover:text-red-500 transition-colors"
           >
             <ArchiveBoxXMarkIcon className="w-5 h-5" />
           </button>
        </div>
      </header>

      <div className="bg-white rounded-[2rem] border border-slate-200 overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead className="bg-slate-50 border-b">
              <tr className="text-[10px] uppercase font-black text-black/30 tracking-widest">
                <th className="px-6 py-4">Deployment Date</th>
                <th className="px-6 py-4">Change ID & Title</th>
                <th className="px-6 py-4">Initiator (Owner)</th>
                <th className="px-6 py-4">Vendor Node</th>
                <th className="px-6 py-4">Execution Status</th>
                <th className="px-6 py-4 text-right">Certificate</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredCrs.map(cr => (
                <tr key={cr.id} className="hover:bg-slate-50/50 transition-colors">
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2 text-xs font-bold text-black">
                      <CalendarIcon className="w-4 h-4 text-brand-orange" />
                      {formatDate(cr.deployedAt)}
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div>
                      <p className="text-[10px] font-black text-brand-orange uppercase">{cr.id}</p>
                      <p className="text-sm font-bold text-black leading-snug">{cr.title}</p>
                    </div>
                  </td>
                  <td className="px-6 py-4 text-sm font-medium text-black/70">
                    {cr.createdBy}
                  </td>
                  <td className="px-6 py-4 text-sm font-mono text-black/60">
                    {cr.vendorName} {cr.versionNumber}
                  </td>
                  <td className="px-6 py-4">
                    <span className={`px-2.5 py-1 rounded-full text-[9px] font-black uppercase border ${
                      cr.status === CRStatus.DEPLOYED 
                        ? 'bg-emerald-50 text-emerald-700 border-emerald-100' 
                        : 'bg-red-50 text-red-700 border-red-100'
                    }`}>
                      {cr.status}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-right">
                    <button 
                      onClick={() => setSelectedCr(cr)}
                      className="p-2.5 bg-amber-50 text-amber-700 border border-amber-200 rounded-xl hover:bg-amber-100 transition-all shadow-sm group"
                      title="View Audit Certificate"
                    >
                      <DocumentArrowDownIcon className="w-5 h-5 group-hover:scale-110 transition-transform" />
                    </button>
                  </td>
                </tr>
              ))}
              {filteredCrs.length === 0 && (
                <tr>
                  <td colSpan={6} className="text-center py-20">
                    <div className="flex flex-col items-center justify-center text-black/20">
                       <MagnifyingGlassIcon className="w-12 h-12 mb-4 opacity-10" />
                       <p className="font-black uppercase tracking-widest text-xs">No matching records</p>
                       <p className="text-[10px] font-medium mt-1">Adjust your date filters to see more historical data.</p>
                    </div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      <div className="bg-orange-50/30 p-6 rounded-2xl border border-orange-100 flex items-center justify-between">
         <div className="flex items-center gap-4">
            <div className="p-3 bg-white rounded-xl border border-orange-100">
               <DocumentChartBarIcon className="w-6 h-6 text-brand-orange" />
            </div>
            <div>
               <p className="text-xs font-black text-black uppercase">Report Analytics</p>
               <p className="text-[10px] text-black/60 font-medium italic">Current search yielded {filteredCrs.length} certified deployment events.</p>
            </div>
         </div>
         <button className="px-6 py-2.5 bg-brand-navy text-white text-[10px] font-black uppercase tracking-widest rounded-xl hover:bg-black transition-all shadow-lg">
            Download Global CSV
         </button>
      </div>

      {selectedCr && (
        <AuditCertificate 
          cr={selectedCr} 
          allUsers={allUsers} 
          onClose={() => setSelectedCr(null)} 
        />
      )}
    </div>
  );
};

export default ReportsPortal;
