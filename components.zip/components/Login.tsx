
import React, { useState } from 'react';
import {
  LockClosedIcon,
  UserIcon,
  EyeIcon,
  EyeSlashIcon,
  UserPlusIcon,
  ArrowLeftOnRectangleIcon,
  IdentificationIcon,
  KeyIcon,
  ChevronDownIcon,
  ChevronUpIcon
} from '@heroicons/react/24/outline';
import { User, UserRole } from '../types';
import { sendOtpEmail } from '../services/otpService';

interface LoginProps {
  onLogin: (user: User) => void;
  onRegister: (user: User) => void;
  allUsers: User[];
  onUpdateUser?: (user: User) => void;
}

const Login: React.FC<LoginProps> = ({ onLogin, onRegister, allUsers, onUpdateUser }) => {
  const [activeTab, setActiveTab] = useState<'login' | 'register' | 'forgot'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('P@ssword123');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [showQuickAccess, setShowQuickAccess] = useState(false);
  const [resetEmail, setResetEmail] = useState('');
  const [sentOtp, setSentOtp] = useState('');
  const [enteredOtp, setEnteredOtp] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [resetStep, setResetStep] = useState<1 | 2 | 3>(1);

  const [regData, setRegData] = useState({
    name: '',
    email: '',
    unit: '',
    phone: 'xxxx',
    password: '',
    role: UserRole.TESTER
  });

  const validateEmailDomain = (emailStr: string) => {
    // Explicitly allow other domains per user request
    return emailStr.includes('@');
  };

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError('');

    if (!validateEmailDomain(email)) {
      setError('Please enter a valid email address.');
      setIsLoading(false);
      return;
    }

    setTimeout(() => {
      const user = allUsers.find(u => u.email.toLowerCase() === email.toLowerCase());
      if (user) {
        // Enforce password match. If the user hasn't set one, default is 'P@ssword123'.
        const expectedPassword = user.password || 'P@ssword123';
        if (password === expectedPassword) {
          onLogin(user);
        } else {
          setError('Invalid credentials.');
          setIsLoading(false);
        }
      } else {
        setError('Staff record not found in registry.');
        setIsLoading(false);
      }
    }, 800);
  };

  const handleRegisterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError('');

    if (!validateEmailDomain(regData.email)) {
      setError('Domain Error: Invalid email format.');
      setIsLoading(false);
      return;
    }

    setTimeout(() => {
      const exists = allUsers.some(u => u.email.toLowerCase() === regData.email.toLowerCase());
      if (exists) {
        setError('Email already exists.');
        setIsLoading(false);
        return;
      }

      const newUser: User = {
        name: regData.name,
        email: regData.email,
        unit: regData.unit,
        phone: regData.phone,
        password: regData.password,
        id: `u-${Date.now()}`,
        roles: [regData.role],
        status: 'active'
      };
      onRegister(newUser);
    }, 800);
  };

  const quickFill = (userEmail: string) => {
    setEmail(userEmail);
    setPassword('P@ssword123');
    setActiveTab('login');
  };

  const handleSendOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError('');

    if (!validateEmailDomain(resetEmail)) {
      setError('Please enter a valid email address.');
      setIsLoading(false);
      return;
    }

    const user = allUsers.find(u => u.email.toLowerCase() === resetEmail.toLowerCase());
    if (!user) {
      setError('Staff record not found in registry.');
      setIsLoading(false);
      return;
    }

    try {
      const generatedOtp = await sendOtpEmail(resetEmail, user.id);
      setSentOtp(generatedOtp);
      setResetStep(2);
    } catch (err) {
      setError('Failed to send OTP. Please try again.');
    }
    setIsLoading(false);
  };

  const handleVerifyOtp = (e: React.FormEvent) => {
    e.preventDefault();
    if (enteredOtp === sentOtp) {
      setResetStep(3);
      setError('');
    } else {
      setError('Invalid OTP code.');
    }
  };

  const handleResetPassword = (e: React.FormEvent) => {
    e.preventDefault();
    if (newPassword.length < 6) {
      setError('Password must be at least 6 characters.');
      return;
    }

    // Actually update the user record
    const user = allUsers.find(u => u.email.toLowerCase() === resetEmail.toLowerCase());
    if (user && onUpdateUser) {
      onUpdateUser({ ...user, password: newPassword });
    }

    setActiveTab('login');
    setResetStep(1);
    setResetEmail('');
    setEnteredOtp('');
    setSentOtp('');
    setNewPassword('');
    setPassword(newPassword);
    setEmail(resetEmail);
    setError('');
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-brand-navy relative overflow-hidden font-sans py-12">
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none">
        <div className="absolute top-[-10%] right-[-5%] w-[600px] h-[600px] bg-brand-orange/30 rounded-full blur-[120px]"></div>
        <div className="absolute bottom-[-10%] left-[-5%] w-[500px] h-[500px] bg-brand-darkOrange/20 rounded-full blur-[100px]"></div>
      </div>

      <div className="w-full max-w-xl px-6 z-10 space-y-6">
        <div className="bg-white/95 backdrop-blur-md rounded-[2.5rem] shadow-[0_40px_100px_rgba(61,15,0,0.5)] overflow-hidden border border-white/20">

          <div className="bg-orange-50/50 border-b border-orange-100 p-8 text-center">
            <div className="inline-flex items-center justify-center w-20 h-20 bg-brand-orange rounded-3xl shadow-2xl mb-6 ring-4 ring-brand-orange/20">
              <span className="text-4xl font-extrabold text-white">N</span>
            </div>
            <h1 className="text-2xl font-black text-black tracking-tight uppercase">Norrepensions</h1>
            <p className="text-brand-orange text-[10px] font-black uppercase tracking-[0.3em] mt-1.5">Governance & Change Portal</p>
          </div>

          <div className="flex bg-orange-50/30">
            <button onClick={() => { setActiveTab('login'); setError(''); }} className={`flex-1 py-5 text-xs font-black uppercase tracking-widest relative ${activeTab === 'login' ? 'text-brand-orange' : 'text-black/40'}`}>
              Authentication
              {activeTab === 'login' && <div className="absolute bottom-0 left-0 w-full h-1 bg-brand-orange"></div>}
            </button>
            <button onClick={() => { setActiveTab('register'); setError(''); }} className={`flex-1 py-5 text-xs font-black uppercase tracking-widest relative ${activeTab === 'register' ? 'text-brand-orange' : 'text-black/40'}`}>
              Registry Signup
              {activeTab === 'register' && <div className="absolute bottom-0 left-0 w-full h-1 bg-brand-orange"></div>}
            </button>
            {activeTab === 'forgot' && (
              <div className="flex-1 py-5 text-xs font-black uppercase tracking-widest relative text-brand-orange border-l border-orange-100 flex items-center justify-center">
                Recovery
                <div className="absolute bottom-0 left-0 w-full h-1 bg-brand-orange"></div>
              </div>
            )}
          </div>

          <div className="p-10 bg-white">
            {activeTab === 'login' && (
              <form onSubmit={handleLoginSubmit} className="space-y-6 animate-fadeIn">
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-black/60 uppercase tracking-widest">Official Email</label>
                  <div className="relative">
                    <UserIcon className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-orange-200" />
                    <input
                      type="email" required
                      className="block w-full pl-12 pr-4 py-4 bg-orange-50/20 border border-orange-100 rounded-2xl text-black font-semibold focus:outline-none focus:ring-2 focus:ring-brand-orange/20 focus:border-brand-orange transition-all"
                      placeholder="surname.othername@norrepensions.com"
                      value={email} onChange={(e) => setEmail(e.target.value)}
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-[10px] font-black text-black/60 uppercase tracking-widest">Password</label>
                  <div className="relative">
                    <LockClosedIcon className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-orange-200" />
                    <input
                      type={showPassword ? "text" : "password"} required
                      className="block w-full pl-12 pr-12 py-4 bg-orange-50/20 border border-orange-100 rounded-2xl text-black font-semibold focus:outline-none focus:ring-2 focus:ring-brand-orange/20 focus:border-brand-orange transition-all"
                      value={password} onChange={(e) => setPassword(e.target.value)}
                    />
                    <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-4 top-1/2 -translate-y-1/2 text-orange-200">
                      {showPassword ? <EyeSlashIcon className="h-5 w-5" /> : <EyeIcon className="h-5 w-5" />}
                    </button>
                  </div>
                  <div className="flex justify-end mt-2">
                    <button type="button" onClick={() => { setActiveTab('forgot'); setResetStep(1); setError(''); }} className="text-[10px] font-bold text-brand-orange hover:underline uppercase tracking-wider">
                      Forgot Password?
                    </button>
                  </div>
                </div>

                {error && <p className="text-xs font-bold text-red-600 bg-red-50 p-3 rounded-xl border border-red-100">{error}</p>}

                <button type="submit" disabled={isLoading} className="w-full py-4 bg-brand-orange text-white rounded-2xl font-black text-xs uppercase tracking-[0.2em] shadow-xl shadow-orange-900/40 hover:bg-orange-600 hover:-translate-y-1 transition-all">
                  {isLoading ? 'Authorizing...' : 'Sign In'}
                </button>
              </form>
            )}

            {activeTab === 'register' && (
              <form onSubmit={handleRegisterSubmit} className="space-y-5 animate-fadeIn">
                <div className="grid grid-cols-1 gap-5">
                  <input required className="block w-full px-4 py-3.5 bg-orange-50/20 border border-orange-100 rounded-2xl text-sm font-semibold focus:border-brand-orange outline-none text-black" placeholder="Full Name" value={regData.name} onChange={e => setRegData({ ...regData, name: e.target.value })} />
                  <input required className="block w-full px-4 py-3.5 bg-orange-50/20 border border-orange-100 rounded-2xl text-sm font-semibold focus:border-brand-orange outline-none text-black" placeholder="Email" value={regData.email} onChange={e => setRegData({ ...regData, email: e.target.value })} />
                  <input type="password" required className="block w-full px-4 py-3.5 bg-orange-50/20 border border-orange-100 rounded-2xl text-sm font-semibold focus:border-brand-orange outline-none text-black" placeholder="Password" value={regData.password} onChange={e => setRegData({ ...regData, password: e.target.value })} />
                  <input required className="block w-full px-4 py-3.5 bg-orange-50/20 border border-orange-100 rounded-2xl text-sm font-semibold focus:border-brand-orange outline-none text-black" placeholder="Unit" value={regData.unit} onChange={e => setRegData({ ...regData, unit: e.target.value })} />
                  <select required className="block w-full px-4 py-3.5 bg-orange-50/20 border border-orange-100 rounded-2xl text-sm font-semibold focus:border-brand-orange outline-none text-black transition-all appearance-none" value={regData.role} onChange={e => setRegData({ ...regData, role: e.target.value as UserRole })}>
                    <option value="" disabled>Select Role...</option>
                    {Object.values(UserRole).filter(role => role !== UserRole.ADMIN).map(role => (
                      <option key={role} value={role}>{role}</option>
                    ))}
                  </select>
                </div>
                <div className="flex justify-end mt-2">
                  <button type="button" onClick={() => { setActiveTab('forgot'); setResetStep(1); setError(''); }} className="text-[10px] font-bold text-brand-orange hover:underline uppercase tracking-wider">
                    Forgot Password?
                  </button>
                </div>
                {error && <p className="text-xs font-bold text-red-600">{error}</p>}
                <button type="submit" className="w-full py-4 bg-brand-orange text-white rounded-2xl font-black text-xs uppercase tracking-[0.2em]">Confirm Registry</button>
              </form>
            )}

            {activeTab === 'forgot' && (
              <div className="space-y-5 animate-fadeIn">
                {resetStep === 1 && (
                  <form onSubmit={handleSendOtp} className="space-y-6">
                    <p className="text-xs text-black/60 font-semibold mb-2">Enter your official email to receive a password recovery OTP.</p>
                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-black/60 uppercase tracking-widest">Official Email</label>
                      <input type="email" required className="block w-full px-4 py-4 bg-orange-50/20 border border-orange-100 rounded-2xl text-sm font-semibold focus:border-brand-orange outline-none text-black" placeholder="surname.othername@norrepensions.com" value={resetEmail} onChange={e => setResetEmail(e.target.value)} />
                    </div>
                    {error && <p className="text-xs font-bold text-red-600 bg-red-50 p-3 rounded-xl border border-red-100">{error}</p>}
                    <button type="submit" disabled={isLoading} className="w-full py-4 bg-brand-orange text-white rounded-2xl font-black text-xs uppercase tracking-[0.2em] shadow-xl shadow-orange-900/40 hover:bg-orange-600 hover:-translate-y-1 transition-all">
                      {isLoading ? 'Sending OTP...' : 'Send OTP'}
                    </button>
                    <button type="button" onClick={() => { setActiveTab('login'); setError(''); }} className="w-full py-2 text-xs font-bold text-black/60 hover:text-brand-orange uppercase tracking-wider">Back to Login</button>
                  </form>
                )}
                {resetStep === 2 && (
                  <form onSubmit={handleVerifyOtp} className="space-y-6">
                    <p className="text-xs text-black/60 font-semibold mb-2">We sent an OTP to <span className="text-brand-orange">{resetEmail}</span>.</p>
                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-black/60 uppercase tracking-widest">Enter OTP Code</label>
                      <input type="text" required className="block w-full px-4 py-4 bg-orange-50/20 border border-orange-100 rounded-2xl text-center tracking-[0.5em] text-lg font-bold focus:border-brand-orange outline-none text-black" placeholder="------" value={enteredOtp} onChange={e => setEnteredOtp(e.target.value)} />
                    </div>
                    {error && <p className="text-xs font-bold text-red-600 bg-red-50 p-3 rounded-xl border border-red-100">{error}</p>}
                    <button type="submit" className="w-full py-4 bg-brand-orange text-white rounded-2xl font-black text-xs uppercase tracking-[0.2em] shadow-xl shadow-orange-900/40 hover:bg-orange-600 hover:-translate-y-1 transition-all">Verify OTP</button>
                    <button type="button" onClick={() => { setResetStep(1); setEnteredOtp(''); }} className="w-full py-2 text-xs font-bold text-black/60 hover:text-brand-orange uppercase tracking-wider">Change Email</button>
                  </form>
                )}
                {resetStep === 3 && (
                  <form onSubmit={handleResetPassword} className="space-y-6">
                    <p className="text-xs text-black/60 font-semibold mb-2">OTP verified. Please set your new password.</p>
                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-black/60 uppercase tracking-widest">New Password</label>
                      <input type="password" required className="block w-full px-4 py-4 bg-orange-50/20 border border-orange-100 rounded-2xl text-sm font-semibold focus:border-brand-orange outline-none text-black" placeholder="Enter new password" value={newPassword} onChange={e => setNewPassword(e.target.value)} />
                    </div>
                    {error && <p className="text-xs font-bold text-red-600 bg-red-50 p-3 rounded-xl border border-red-100">{error}</p>}
                    <button type="submit" className="w-full py-4 bg-brand-orange text-white rounded-2xl font-black text-xs uppercase tracking-[0.2em] shadow-xl shadow-orange-900/40 hover:bg-orange-600 hover:-translate-y-1 transition-all">Reset Password</button>
                  </form>
                )}
              </div>
            )}
          </div>
        </div>

      </div>
    </div>
  );
};

export default Login;
