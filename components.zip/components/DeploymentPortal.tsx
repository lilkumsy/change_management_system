
import React from 'react';
import { 
  RocketLaunchIcon, 
  DocumentArrowDownIcon, 
  CheckCircleIcon,
  ClockIcon,
  XCircleIcon,
  LockClosedIcon,
  UserCircleIcon
} from '@heroicons/react/24/outline';
import { ChangeRequest, CRStatus, User } from '../types';

interface DeploymentProps {
  crs: ChangeRequest[];
  onDeploy: (crId: string, success: boolean) => void;
  currentUser: User;
}

const DeploymentPortal: React.FC<DeploymentProps> = ({ crs, onDeploy, currentUser }) => {
  // Filter for requests where this user is the assigned deployment engineer OR they are admin
  const deployments = crs.filter(cr => 
    cr.status === CRStatus.APPROVED_FOR_DEPLOYMENT || 
    cr.status === CRStatus.DEPLOYED || 
    cr.status === CRStatus.DEPLOYMENT_FAILED
  );

  return (
    <div className="space-y-6 text-black">
      <header className="flex justify-between items-end">
        <div>
          <h2 className="text-3xl font-bold">Production Release</h2>
          <p className="text-black/60 font-medium">Final authorization and execution of core banking updates.</p>
        </div>
      </header>

      <div className="space-y-6">
        {deployments.map(cr => {
          const isAssigned = cr.itApproval?.deploymentEngineerId === currentUser.id;
          const isAdmin = currentUser.roles.includes('System Admin' as any);
          const canAction = (isAssigned || isAdmin) && cr.status === CRStatus.APPROVED_FOR_DEPLOYMENT;

          return (
            <div key={cr.id} className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden animate-slideUp">
              <div className="bg-slate-50 p-6 flex flex-col md:flex-row md:items-center justify-between gap-4 border-b">
                <div className="flex items-center gap-4">
                  <div className={`p-3 rounded-2xl shadow-sm border ${
                    cr.status === CRStatus.DEPLOYED ? 'bg-emerald-50 border-emerald-100' : 'bg-white'
                  }`}>
                     <RocketLaunchIcon className={`w-8 h-8 ${
                       cr.status === CRStatus.DEPLOYED ? 'text-emerald-500' : 
                       cr.status === CRStatus.DEPLOYMENT_FAILED ? 'text-red-500' : 'text-brand-orange'
                     }`} />
                  </div>
                  <div>
                     <div className="flex items-center gap-2">
                       <h3 className="text-xl font-bold">{cr.id}</h3>
                       <span className={`px-2 py-0.5 rounded-full text-[10px] font-black uppercase tracking-widest border ${
                         cr.status === CRStatus.DEPLOYED ? 'bg-emerald-100 text-emerald-700 border-emerald-200' : 
                         cr.status === CRStatus.DEPLOYMENT_FAILED ? 'bg-red-100 text-red-700 border-red-200' : 'bg-brand-orange text-white'
                       }`}>
                         {cr.status}
                       </span>
                     </div>
                     <p className="text-black/70 font-bold">{cr.title}</p>
                  </div>
                </div>

                <div className="flex items-center gap-3 no-print">
                  {!canAction && cr.status === CRStatus.APPROVED_FOR_DEPLOYMENT && (
                    <div className="flex items-center gap-2 px-4 py-2 bg-slate-100 rounded-xl text-[10px] font-black text-black/40 uppercase tracking-widest">
                      <LockClosedIcon className="w-4 h-4" /> Assigned to other engineer
                    </div>
                  )}

                  {canAction && (
                    <>
                      <button 
                        onClick={() => onDeploy(cr.id, false)}
                        className="bg-white border-2 border-red-100 text-red-600 px-4 py-2.5 rounded-xl text-xs font-black hover:bg-red-50 transition-all uppercase tracking-widest flex items-center gap-2"
                      >
                        <XCircleIcon className="w-5 h-5" /> Log Failure
                      </button>
                      <button 
                        onClick={() => onDeploy(cr.id, true)}
                        className="bg-brand-orange text-white px-6 py-2.5 rounded-xl text-xs font-black hover:bg-orange-600 shadow-lg shadow-brand-orange/20 transition-all uppercase tracking-widest flex items-center gap-2"
                      >
                        <CheckCircleIcon className="w-5 h-5" /> Certify Success
                      </button>
                    </>
                  )}
                  
                  {(cr.status === CRStatus.DEPLOYED || cr.status === CRStatus.DEPLOYMENT_FAILED) && (
                    <div className="px-4 py-2 bg-emerald-50 rounded-xl text-[10px] font-black text-emerald-600 uppercase border border-emerald-100">
                      Execution Recorded
                    </div>
                  )}
                </div>
              </div>

              <div className="p-8 grid grid-cols-1 md:grid-cols-3 gap-12">
                 <div className="space-y-4">
                   <h4 className="text-[10px] uppercase font-black text-black/40 tracking-widest">Signed Evidence Hub</h4>
                   <div className="space-y-3">
                      <div className="flex items-center gap-3">
                         <CheckCircleIcon className="w-5 h-5 text-emerald-500" />
                         <div className="text-sm">
                           <p className="font-bold">Risk Certification</p>
                           <p className="text-black/60 text-[10px] font-medium">{cr.riskAssessment?.assessedBy}</p>
                         </div>
                      </div>
                      <div className="flex items-center gap-3">
                         <CheckCircleIcon className="w-5 h-5 text-emerald-500" />
                         <div className="text-sm">
                           <p className="font-bold">IT Authorization</p>
                           <p className="text-black/60 text-[10px] font-medium">{cr.itApproval?.approvedBy}</p>
                         </div>
                      </div>
                      <div className="flex items-center gap-3">
                         <UserCircleIcon className="w-5 h-5 text-brand-orange" />
                         <div className="text-sm">
                           <p className="font-bold">Lead Engineer</p>
                           <p className="text-black/60 text-[10px] font-medium italic">Assigned for execution</p>
                         </div>
                      </div>
                   </div>
                 </div>

                 <div className="md:col-span-2 space-y-4">
                    <h4 className="text-[10px] uppercase font-black text-black/40 tracking-widest">Environment Target Details</h4>
                    <div className="bg-slate-50 rounded-2xl p-6 border border-slate-100 space-y-4">
                       <div className="grid grid-cols-2 gap-6 text-xs font-mono">
                          <div>
                             <p className="text-black/30 mb-1">VENDOR VERSION</p>
                             <p className="font-bold text-black text-sm">{cr.versionNumber}</p>
                          </div>
                          <div>
                             <p className="text-black/30 mb-1">TARGET CLUSTER</p>
                             <p className="font-bold text-black text-sm">PROD_LIVE_NORREN_01</p>
                          </div>
                       </div>
                       <div className="pt-4 border-t border-slate-200">
                          <p className="text-[10px] font-black text-black/40 mb-2 uppercase">Executive Instructions</p>
                          <p className="text-xs text-black/70 italic bg-white p-3 rounded-lg border border-slate-100 leading-relaxed">
                            "{cr.itApproval?.comments || 'Proceed with standard production migration protocol.'}"
                          </p>
                       </div>
                    </div>
                 </div>
              </div>
            </div>
          );
        })}
        {deployments.length === 0 && (
           <div className="text-center py-24 text-black/20 border-2 border-dashed rounded-[3rem] border-slate-100">
              <RocketLaunchIcon className="w-16 h-16 mx-auto mb-4 opacity-10" />
              <p className="font-black uppercase tracking-widest text-xs">No Deployment Tasks</p>
              <p className="text-[10px] font-medium mt-1">Pending IT sign-off for new production requests.</p>
           </div>
        )}
      </div>
    </div>
  );
};

export default DeploymentPortal;
