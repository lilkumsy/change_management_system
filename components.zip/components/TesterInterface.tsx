import React, { useState } from 'react';
import { 
  CheckCircleIcon, 
  XCircleIcon, 
  ExclamationTriangleIcon,
  CameraIcon,
  BeakerIcon
} from '@heroicons/react/24/solid';
import { ChangeRequest, TestResult, ChangeFeature } from '../types';

interface TesterProps {
  crs: ChangeRequest[];
  currentUser: any;
  onUpdateFeature: (crId: string, featureId: string, updates: Partial<ChangeFeature>) => void;
}

const TesterInterface: React.FC<TesterProps> = ({ crs, currentUser, onUpdateFeature }) => {
  const [selectedFeature, setSelectedFeature] = useState<{cr: ChangeRequest, feature: ChangeFeature} | null>(null);
  const [feedback, setFeedback] = useState({ result: TestResult.PASS, observations: '', screenshots: '' });

  const assignedTasks = crs.flatMap(cr => 
    cr.features
      .filter(f => f.assignedTesterId === currentUser.id)
      .map(f => ({ cr, feature: f }))
  );

  const handleSubmitFeedback = () => {
    if (!selectedFeature) return;
    onUpdateFeature(selectedFeature.cr.id, selectedFeature.feature.id, {
      testResult: feedback.result,
      testObservations: feedback.observations,
      status: 'Tested',
      testTimestamp: new Date().toISOString()
    });
    setSelectedFeature(null);
  };

  return (
    <div className="space-y-6 text-black">
      <header>
        <h2 className="text-3xl font-bold">My Testing Dashboard</h2>
        <p className="text-black/60 font-medium">Executing user acceptance for assigned features.</p>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-1 space-y-4">
          <h3 className="text-sm font-bold text-black/50 uppercase tracking-widest">Pending Assignments</h3>
          {assignedTasks.map(({ cr, feature }) => (
            <div 
              key={feature.id}
              onClick={() => setSelectedFeature({ cr, feature })}
              className={`p-4 rounded-2xl border cursor-pointer transition-all ${
                selectedFeature?.feature.id === feature.id 
                ? 'border-brand-orange bg-orange-50 ring-2 ring-brand-orange/10 shadow-sm' 
                : 'bg-white border-slate-200 hover:border-brand-orange/50'
              }`}
            >
              <div className="flex justify-between items-start mb-2">
                <span className="text-[10px] font-bold text-brand-orange uppercase tracking-tighter">{cr.id}</span>
                {feature.status === 'Tested' && (
                   <span className="text-[10px] font-bold text-emerald-600 uppercase">Completed</span>
                )}
              </div>
              <h4 className="font-bold text-black line-clamp-1">{feature.name}</h4>
              <p className="text-xs text-black/60 mt-1 line-clamp-2">{feature.description}</p>
              <div className="mt-3 flex items-center gap-2">
                 <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${
                   feature.riskLevel === 'High' ? 'bg-red-100 text-red-700' : 'bg-brand-orange/10 text-brand-orange'
                 }`}>
                   {feature.riskLevel} Risk
                 </span>
                 <span className="text-[10px] text-black/30">Due: {cr.plannedEndDate}</span>
              </div>
            </div>
          ))}
          {assignedTasks.length === 0 && (
            <div className="p-8 text-center text-black/40 italic font-medium">No testing tasks assigned to you.</div>
          )}
        </div>

        <div className="lg:col-span-2">
          {selectedFeature ? (
            <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-8 space-y-8 animate-slideUp">
              <div className="border-b pb-6">
                <h3 className="text-2xl font-bold text-black">{selectedFeature.feature.name}</h3>
                <p className="text-black/70 mt-2">{selectedFeature.feature.description}</p>
                <div className="mt-4 flex items-center gap-6">
                  <div>
                    <p className="text-[10px] font-bold text-black/40 uppercase">Change Request</p>
                    <p className="text-sm font-medium text-black">{selectedFeature.cr.title}</p>
                  </div>
                  <div>
                    <p className="text-[10px] font-bold text-black/40 uppercase">Module</p>
                    <p className="text-sm font-medium text-black">{selectedFeature.feature.module}</p>
                  </div>
                </div>
              </div>

              <div className="space-y-6">
                <div>
                  <label className="text-sm font-bold text-black block mb-3">Test Result Outcome</label>
                  <div className="grid grid-cols-3 gap-4">
                    {[
                      { val: TestResult.PASS, icon: CheckCircleIcon, color: 'text-emerald-500', bg: 'bg-emerald-50', border: 'border-emerald-200' },
                      { val: TestResult.FAIL, icon: XCircleIcon, color: 'text-red-500', bg: 'bg-red-50', border: 'border-red-200' },
                      { val: TestResult.CONDITIONAL, icon: ExclamationTriangleIcon, color: 'text-amber-500', bg: 'bg-amber-50', border: 'border-amber-200' },
                    ].map(res => (
                      <button
                        key={res.val}
                        onClick={() => setFeedback({ ...feedback, result: res.val })}
                        className={`flex flex-col items-center gap-2 p-4 rounded-2xl border transition-all ${
                          feedback.result === res.val ? `${res.bg} ${res.border} scale-105 shadow-md border-transparent` : 'border-slate-100 hover:border-slate-200'
                        }`}
                      >
                        <res.icon className={`w-8 h-8 ${res.color}`} />
                        <span className={`text-xs font-bold ${res.color}`}>{res.val}</span>
                      </button>
                    ))}
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-bold text-black block">Execution Observations</label>
                  <textarea 
                    className="w-full border rounded-2xl p-4 min-h-[150px] outline-none focus:ring-2 focus:ring-brand-orange/50 text-black"
                    placeholder="Detail the steps taken and any discrepancies found..."
                    value={feedback.observations}
                    onChange={e => setFeedback({...feedback, observations: e.target.value})}
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-bold text-black block">Supporting Evidence (Upload Logs/Screenshots)</label>
                  <div className="flex items-center justify-center w-full">
                    <label className="flex flex-col items-center justify-center w-full h-32 border-2 border-slate-200 border-dashed rounded-2xl cursor-pointer bg-slate-50 hover:bg-slate-100 transition-colors">
                      <div className="flex flex-col items-center justify-center pt-5 pb-6">
                        <CameraIcon className="w-8 h-8 text-black/30 mb-2" />
                        <p className="text-sm text-black/60"><span className="font-semibold">Click to upload</span> or drag and drop</p>
                        <p className="text-xs text-black/40">PNG, JPG, PDF (MAX. 5MB)</p>
                      </div>
                      <input type="file" className="hidden" />
                    </label>
                  </div>
                </div>

                <button 
                  onClick={handleSubmitFeedback}
                  className="w-full bg-brand-orange text-white py-4 rounded-2xl font-bold hover:bg-orange-600 shadow-xl shadow-brand-orange/30 transition-all"
                >
                  Submit Certified Testing Feedback
                </button>
              </div>
            </div>
          ) : (
            <div className="h-full flex flex-col items-center justify-center text-black/20 bg-white border border-slate-200 border-dashed rounded-2xl p-12">
              <BeakerIcon className="w-16 h-16 mb-4 text-black/10" />
              <p className="font-medium">Select a feature from the left to begin testing.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default TesterInterface;