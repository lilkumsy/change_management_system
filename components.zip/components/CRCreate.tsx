
import React, { useState, useEffect } from 'react';
import { DocumentTextIcon, PlusIcon, TrashIcon, ArrowLeftIcon } from '@heroicons/react/24/outline';
import { CRStatus, ChangeFeature, RiskLevel, ChangeRequest, UserRole, User } from '../types';

interface CRCreateProps {
  onCreate: (cr: ChangeRequest) => void;
  onUpdate?: (cr: ChangeRequest) => void;
  onCancel?: () => void;
  currentUser: User;
  allUsers?: User[];
  editingCR?: ChangeRequest | null;
}

const CRCreate: React.FC<CRCreateProps> = ({ onCreate, onUpdate, onCancel, currentUser, allUsers = [], editingCR }) => {
  const [formData, setFormData] = useState({
    title: '',
    vendorName: '',
    versionNumber: '',
    environment: 'TEST',
    plannedStartDate: '',
    plannedEndDate: '',
  });
  const [features, setFeatures] = useState<Partial<ChangeFeature>[]>([]);

  useEffect(() => {
    if (editingCR) {
      setFormData({
        title: editingCR.title,
        vendorName: editingCR.vendorName,
        versionNumber: editingCR.versionNumber,
        environment: editingCR.environment,
        plannedStartDate: editingCR.plannedStartDate,
        plannedEndDate: editingCR.plannedEndDate,
      });
      setFeatures(editingCR.features);
    }
  }, [editingCR]);

  const testerUsers = allUsers.filter(u => u.roles.includes(UserRole.TESTER));

  const addManualFeature = () => {
    setFeatures([...features, {
      id: `f-${Date.now()}`,
      name: '',
      description: '',
      module: '',
      riskLevel: RiskLevel.MEDIUM,
      assignedTesterId: '',
      status: 'Pending'
    }]);
  };

  const removeFeature = (id: string) => {
    setFeatures(features.filter(f => f.id !== id));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const updatedStatus = features.some(f => f.assignedTesterId) ? CRStatus.TESTING_ASSIGNED : CRStatus.INITIATED;
    
    if (editingCR && onUpdate) {
      const updatedCR: ChangeRequest = {
        ...editingCR,
        ...formData,
        features: features as ChangeFeature[],
        status: editingCR.status === CRStatus.INITIATED || editingCR.status === CRStatus.TESTING_ASSIGNED ? updatedStatus : editingCR.status,
      };
      onUpdate(updatedCR);
    } else {
      const newCR: ChangeRequest = {
        ...formData,
        id: `CR-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`,
        status: updatedStatus,
        features: features as ChangeFeature[],
        auditLogs: [{
          id: `a-${Date.now()}`,
          action: 'CR Created',
          user: currentUser.name,
          timestamp: new Date().toISOString(),
          details: `Initial CR submission with ${features.length} features.`
        }],
        createdAt: new Date().toISOString(),
        createdBy: currentUser.name,
      };
      onCreate(newCR);
    }
  };

  return (
    <div className="space-y-8 pb-20 animate-fadeIn text-black">
      <header className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold">{editingCR ? 'Modify Change Request' : 'Initiate Change Request'}</h2>
          <p className="text-black/60 font-medium">{editingCR ? `Refining ${editingCR.id}` : 'Official Change Governance Portal'}</p>
        </div>
        {onCancel && <button onClick={onCancel} className="flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-bold text-black/40 hover:text-brand-orange hover:bg-orange-50 transition-all"><ArrowLeftIcon className="w-4 h-4" /> Go Back</button>}
      </header>

      <form onSubmit={handleSubmit} className="space-y-8">
        <section className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
          <h3 className="text-lg font-bold mb-4 flex items-center gap-2"><DocumentTextIcon className="w-5 h-5 text-brand-orange" />General Information</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <input required className="w-full border p-2.5 rounded-xl text-black font-semibold" placeholder="Change Title" value={formData.title} onChange={e => setFormData({...formData, title: e.target.value})} />
            <input required className="w-full border p-2.5 rounded-xl text-black font-semibold" placeholder="Vendor" value={formData.vendorName} onChange={e => setFormData({...formData, vendorName: e.target.value})} />
            <input required className="w-full border p-2.5 rounded-xl text-black font-semibold" placeholder="Version" value={formData.versionNumber} onChange={e => setFormData({...formData, versionNumber: e.target.value})} />
            <div className="flex items-center gap-2">
              <input type="date" className="w-full border p-2.5 rounded-xl text-black" value={formData.plannedStartDate} onChange={e => setFormData({...formData, plannedStartDate: e.target.value})} />
              <input type="date" className="w-full border p-2.5 rounded-xl text-black" value={formData.plannedEndDate} onChange={e => setFormData({...formData, plannedEndDate: e.target.value})} />
            </div>
          </div>
        </section>

        <section className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-bold">Features & Assignments</h3>
            <button type="button" onClick={addManualFeature} className="text-brand-orange font-bold text-sm">+ Add Feature</button>
          </div>
          <div className="space-y-4">
            {features.map((feature, idx) => (
              <div key={feature.id} className="p-4 border rounded-2xl grid grid-cols-1 md:grid-cols-12 gap-4 bg-slate-50/50">
                <div className="md:col-span-3"><input className="w-full font-bold bg-transparent outline-none" placeholder="Feature Name" value={feature.name} onChange={e => { const f = [...features]; f[idx].name = e.target.value; setFeatures(f); }} /></div>
                <div className="md:col-span-5"><textarea className="w-full text-sm bg-transparent outline-none" placeholder="Description" value={feature.description} onChange={e => { const f = [...features]; f[idx].description = e.target.value; setFeatures(f); }} /></div>
                <div className="md:col-span-2"><select className="w-full text-xs p-2 border rounded-lg" value={feature.riskLevel} onChange={e => { const f = [...features]; f[idx].riskLevel = e.target.value as RiskLevel; setFeatures(f); }}><option value={RiskLevel.LOW}>Low</option><option value={RiskLevel.MEDIUM}>Medium</option><option value={RiskLevel.HIGH}>High</option></select></div>
                <div className="md:col-span-2 flex items-center gap-2">
                  <select required className="w-full text-xs p-2 border rounded-lg" value={feature.assignedTesterId} onChange={e => { const f = [...features]; f[idx].assignedTesterId = e.target.value; setFeatures(f); }}><option value="">Assign Tester...</option>{testerUsers.map(u => <option key={u.id} value={u.id}>{u.name}</option>)}</select>
                  <button type="button" onClick={() => removeFeature(feature.id!)}><TrashIcon className="w-4 h-4 text-red-400" /></button>
                </div>
              </div>
            ))}
          </div>
        </section>

        <div className="flex justify-end gap-4">
          <button type="submit" className="bg-brand-orange text-white px-10 py-3 rounded-xl font-black text-xs uppercase tracking-widest shadow-xl hover:bg-orange-600 transition-all">
            {editingCR ? 'Save Changes' : 'Initiate Request'}
          </button>
        </div>
      </form>
    </div>
  );
};

export default CRCreate;
