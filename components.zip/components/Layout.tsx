
import React, { useState, useEffect, useRef } from 'react';
import { 
  HomeIcon, 
  PlusCircleIcon, 
  BeakerIcon, 
  ShieldCheckIcon, 
  CheckBadgeIcon, 
  RocketLaunchIcon,
  UsersIcon,
  ArrowRightOnRectangleIcon,
  QuestionMarkCircleIcon,
  BellIcon,
  GlobeAltIcon,
  DocumentChartBarIcon
} from '@heroicons/react/24/outline';
import { User, UserRole, AppNotification } from '../types';

interface LayoutProps {
  children: React.ReactNode;
  currentUser: User;
  onLogout: () => void;
  onNavigate: (view: string) => void;
  activeView: string;
  notifications: AppNotification[];
  onMarkNotificationRead: (id: string) => void;
}

const Layout: React.FC<LayoutProps> = ({ 
  children, 
  currentUser, 
  onLogout, 
  onNavigate, 
  activeView, 
  notifications,
  onMarkNotificationRead
}) => {
  const [showNotifs, setShowNotifs] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if ("Notification" in window && Notification.permission === "default") {
      Notification.requestPermission();
    }
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setShowNotifs(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: HomeIcon, roles: Object.values(UserRole) },
    { id: 'create-cr', label: 'Initiate CR', icon: PlusCircleIcon, roles: [UserRole.DB_TEAM, UserRole.ADMIN] },
    { id: 'tester-view', label: 'My Testing', icon: BeakerIcon, roles: [UserRole.TESTER, UserRole.ADMIN] },
    { id: 'risk-view', label: 'Risk Reviews', icon: ShieldCheckIcon, roles: [UserRole.RISK_TEAM, UserRole.ADMIN] },
    { id: 'it-approval', label: 'IT Approvals', icon: CheckBadgeIcon, roles: [UserRole.HEAD_OF_IT, UserRole.ADMIN] },
    { id: 'deployment', label: 'Deployment', icon: RocketLaunchIcon, roles: [UserRole.DEPLOYMENT_ENGINEER, UserRole.ADMIN] },
    { id: 'reports', label: 'Reports', icon: DocumentChartBarIcon, roles: [UserRole.ADMIN] },
    { id: 'user-management', label: 'Profile & Users', icon: UsersIcon, roles: Object.values(UserRole) },
    { id: 'help-faq', label: 'Help & Support', icon: QuestionMarkCircleIcon, roles: Object.values(UserRole) },
  ];

  const unreadCount = notifications.filter(n => !n.read && n.userId === currentUser.id).length;
  
  const getViewTitle = () => {
    const item = menuItems.find(i => i.id === activeView);
    return item ? item.label : 'General Overview';
  };

  const userHasPermission = (itemRoles: UserRole[]) => {
    return itemRoles.some(role => currentUser.roles.includes(role));
  };

  return (
    <div className="min-h-screen flex flex-col md:flex-row bg-brand-light">
      <aside className="w-full md:w-64 bg-brand-navy text-black flex-shrink-0 flex flex-col no-print shadow-2xl z-20">
        <div className="p-6 flex items-center space-x-3 bg-brand-darkBlue border-b border-orange-950/30">
          <div className="w-10 h-10 bg-brand-orange rounded-lg flex items-center justify-center text-white font-bold text-xl shadow-lg">N</div>
          <div className="overflow-hidden">
            <h1 className="text-white font-bold tracking-tight text-xs uppercase truncate">NORRENPENSIONS</h1>
            <p className="text-[9px] text-brand-orange font-bold tracking-widest uppercase">Pensions CMS</p>
          </div>
        </div>

        <nav className="flex-grow p-4 space-y-2 overflow-y-auto">
          {menuItems
            .filter(item => userHasPermission(item.roles))
            .map((item) => (
            <button
              key={item.id}
              onClick={() => onNavigate(item.id)}
              className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl transition-all duration-200 ${
                activeView === item.id 
                  ? 'bg-brand-orange text-black shadow-xl font-bold' 
                  : 'text-white/80 hover:bg-orange-900/40 hover:text-white'
              }`}
            >
              <item.icon className="w-6 h-6" />
              <span className="font-medium">{item.label}</span>
            </button>
          ))}
        </nav>

        <div className="px-4 py-3 border-t border-orange-900/20">
          <div className="w-full flex items-center gap-3 px-4 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest bg-sky-500/10 text-sky-400 border border-sky-500/20">
            <GlobeAltIcon className="w-4 h-4" />
            <div className="text-left flex-grow">
              <p className="leading-none text-sky-400">System Secure</p>
              <p className="text-[8px] opacity-60 mt-0.5">TLS 1.3 Active</p>
            </div>
          </div>
        </div>

        <div className="p-4 bg-brand-darkBlue border-t border-orange-900/30">
          <div className="flex items-center justify-between mb-4 px-2">
            <div className="flex items-center space-x-3 overflow-hidden">
              <div className="w-10 h-10 rounded-full bg-brand-orange flex items-center justify-center text-white font-bold text-lg border border-orange-400/20">
                {currentUser.name.charAt(0)}
              </div>
              <div className="overflow-hidden">
                <p className="text-sm font-semibold text-white truncate">{currentUser.name}</p>
                <p className="text-[10px] text-orange-300/60 uppercase tracking-tight truncate">{currentUser.roles.join(', ')}</p>
              </div>
            </div>
            <button 
              onClick={onLogout}
              className="p-2 hover:bg-orange-800/40 rounded-lg text-orange-400 hover:text-white transition-colors"
            >
              <ArrowRightOnRectangleIcon className="w-5 h-5" />
            </button>
          </div>
          <div className="px-2">
            <p className="text-[8px] text-orange-900 font-mono text-center">NOR-CMS v2.7.0</p>
          </div>
        </div>
      </aside>

      <div className="flex-grow flex flex-col h-screen overflow-hidden">
        <header className="h-20 bg-white/80 backdrop-blur-md border-b border-orange-100 px-8 flex items-center justify-between z-30 no-print sticky top-0">
          <div className="flex items-center space-x-2">
             <span className="text-[10px] font-black uppercase tracking-[0.2em] text-black/30">Workspace /</span>
             <span className="text-sm font-bold text-black">{getViewTitle()}</span>
          </div>

          <div className="flex items-center space-x-6">
            <div className="hidden lg:flex items-center space-x-2 px-3 py-1.5 rounded-full bg-emerald-50 border border-emerald-100">
               <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></div>
               <span className="text-[10px] font-black text-emerald-600 uppercase">Live Systems</span>
            </div>

            <div className="relative" ref={dropdownRef}>
              <button
                onClick={() => setShowNotifs(!showNotifs)}
                className={`relative p-2.5 rounded-full transition-all duration-200 border ${
                  showNotifs 
                    ? 'bg-brand-orange text-white border-brand-orange shadow-lg' 
                    : 'text-black/40 border-slate-200 hover:border-brand-orange/50 hover:bg-orange-50 hover:text-brand-orange'
                }`}
              >
                <BellIcon className="w-6 h-6" />
                {unreadCount > 0 && (
                  <span className="absolute top-0 right-0 w-5 h-5 bg-red-500 rounded-full text-[10px] font-bold text-white flex items-center justify-center border-2 border-white ring-2 ring-red-500/20">
                    {unreadCount}
                  </span>
                )}
              </button>

              {showNotifs && (
                <div className="absolute right-0 mt-4 w-80 bg-white rounded-3xl shadow-[0_20px_60px_rgba(61,15,0,0.15)] border border-orange-50 py-0 animate-fadeIn overflow-hidden">
                  <div className="px-6 py-4 border-b border-orange-50 flex justify-between items-center bg-orange-50/30">
                    <h4 className="text-xs font-black uppercase tracking-widest text-brand-orange">Alert Hub</h4>
                    <span className="text-[9px] font-bold bg-white px-2 py-0.5 rounded-full border border-orange-100 text-black/40">{unreadCount} UNREAD</span>
                  </div>
                  <div className="max-h-96 overflow-y-auto custom-scrollbar">
                    {notifications.filter(n => n.userId === currentUser.id).length === 0 ? (
                      <div className="p-10 text-center text-black/20 text-[10px] font-black uppercase italic tracking-widest">No active alerts</div>
                    ) : (
                      notifications
                        .filter(n => n.userId === currentUser.id)
                        .map(n => (
                        <div 
                          key={n.id} 
                          onClick={() => { onMarkNotificationRead(n.id); setShowNotifs(false); }}
                          className={`px-6 py-4 hover:bg-orange-50/50 cursor-pointer border-b border-orange-50 last:border-0 transition-colors ${!n.read ? 'bg-brand-orange/5' : ''}`}
                        >
                          <div className="flex gap-4">
                             <div className={`mt-1.5 w-2 h-2 rounded-full flex-shrink-0 ${!n.read ? 'bg-brand-orange animate-pulse shadow-[0_0_8px_rgba(245,57,0,0.4)]' : 'bg-slate-200'}`}></div>
                             <div>
                                <p className="text-xs font-bold text-black leading-tight">{n.title}</p>
                                <p className="text-[10px] text-black/60 mt-1 line-clamp-2 leading-relaxed">{n.message}</p>
                                <p className="text-[8px] text-black/30 mt-2 uppercase font-black tracking-tighter">{new Date(n.timestamp).toLocaleTimeString()}</p>
                             </div>
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              )}
            </div>
          </div>
        </header>

        <main className="flex-grow overflow-y-auto p-4 md:p-8 custom-scrollbar">
          <div className="max-w-6xl mx-auto">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
};

export default Layout;
