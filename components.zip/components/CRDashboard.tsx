
import React, { useState } from 'react';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell 
} from 'recharts';
import { 
  PencilSquareIcon, 
  TrashIcon, 
  LockClosedIcon, 
  DocumentArrowDownIcon,
} from '@heroicons/react/24/outline';
import { ChangeRequest, CRStatus, User, UserRole } from '../types';
import { STATUS_COLORS, STATUS_ICONS } from '../constants';
import AuditCertificate from './AuditCertificate';

interface DashboardProps {
  crs: ChangeRequest[];
  onSelectCR: (crId: string) => void;
  onEditCR: (cr: ChangeRequest) => void;
  onDeleteCR: (crId: string) => void;
  currentUser: User;
  allUsers: User[];
}

const CRDashboard: React.FC<DashboardProps> = ({ crs, onSelectCR, onEditCR, onDeleteCR, currentUser, allUsers }) => {
  const [selectedReportCr, setSelectedReportCr] = useState<ChangeRequest | null>(null);

  const statusCounts = Object.values(CRStatus).map(status => ({
    name: status,
    count: crs.filter(cr => cr.status === status).length
  }));

  const COLORS = ['#7a1d00', '#f53900', '#A13A02', '#D97706', '#F59E0B', '#10B981', '#22C55E', '#ef4444', '#94A3B8'];

  const canManage = (cr: ChangeRequest) => {
    const isOwnerOrAdmin = currentUser.roles.includes(UserRole.ADMIN) || currentUser.id === cr.creatorId;
    const isEditableStatus = cr.status === CRStatus.INITIATED || cr.status === CRStatus.TESTING_ASSIGNED;
    return isOwnerOrAdmin && isEditableStatus;
  };

  const isLocked = (cr: ChangeRequest) => {
    return cr.status !== CRStatus.INITIATED && cr.status !== CRStatus.TESTING_ASSIGNED;
  };

  const showCertificate = (cr: ChangeRequest) => {
    return (cr.status === CRStatus.DEPLOYED || cr.status === CRStatus.DEPLOYMENT_FAILED) && 
           (currentUser.id === cr.creatorId || currentUser.roles.includes(UserRole.ADMIN));
  };

  return (
    <div className="space-y-8 animate-fadeIn relative text-black">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b pb-6 border-orange-100">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Governance Overview</h2>
          <p className="text-black/60 font-medium italic">Compliance tracking and audit evidence for Norrenpensions.</p>
        </div>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        {[
          { label: 'Active Requests', val: crs.filter(c => c.status !== CRStatus.CLOSED).length },
          { label: 'In Testing', val: crs.filter(c => c.status === CRStatus.TESTING_ASSIGNED).length },
          { label: 'Risk Verified', val: crs.filter(c => c.status === CRStatus.RISK_REVIEWED).length },
          { label: 'Success Deployed', val: crs.filter(c => c.status === CRStatus.DEPLOYED).length },
        ].map((stat, i) => (
          <div key={i} className="bg-white p-6 rounded-2xl shadow-sm border border-orange-100 group hover:border-brand-orange transition-all">
            <p className="text-[10px] font-black text-black/40 uppercase tracking-widest">{stat.label}</p>
            <p className="text-4xl font-black mt-2 text-black group-hover:text-brand-orange transition-colors">{stat.val}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="bg-white p-8 rounded-3xl shadow-sm border border-orange-100">
          <h3 className="text-lg font-black uppercase tracking-tight mb-6">Lifecycle Distribution</h3>
          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={statusCounts}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#fee2e2" />
                <XAxis dataKey="name" hide />
                <YAxis allowDecimals={false} axisLine={false} tick={{fill: '#000000', fontSize: 10, fontWeight: 'bold'}} />
                <Tooltip 
                  cursor={{fill: 'transparent'}}
                  contentStyle={{borderRadius: '16px', border: 'none', boxShadow: '0 10px 30px rgba(0,0,0,0.1)', color: '#000', fontWeight: 'bold'}} 
                />
                <Bar dataKey="count" radius={[8, 8, 0, 0]} barSize={30}>
                  {statusCounts.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white p-8 rounded-3xl shadow-sm border border-orange-100 flex flex-col">
          <h3 className="text-lg font-black uppercase tracking-tight mb-6">Registry Tracking</h3>
          <div className="space-y-4 flex-grow overflow-y-auto max-h-[450px] pr-2 custom-scrollbar">
            {crs.map((cr) => (
              <div key={cr.id} className="group flex items-center justify-between p-5 rounded-2xl border border-slate-50 hover:border-brand-orange hover:bg-orange-50/20 transition-all">
                <div className="cursor-pointer flex-grow" onClick={() => onSelectCR(cr.id)}>
                  <div className="flex items-center space-x-2">
                    <span className="text-xs font-black text-black">{cr.id}</span>
                    <span className={`px-2 py-0.5 rounded-full text-[9px] font-black border uppercase tracking-tighter ${STATUS_COLORS[cr.status]}`}>{cr.status}</span>
                  </div>
                  <h4 className="font-bold text-black mt-1 group-hover:text-brand-orange transition-colors">{cr.title}</h4>
                  <div className="flex items-center gap-2 mt-2">
                    <p className="text-[9px] text-black/30 font-bold uppercase tracking-widest">Initiator: {cr.createdBy}</p>
                    {isLocked(cr) && <span className="flex items-center gap-1 text-[8px] font-black text-slate-300 uppercase tracking-tighter bg-slate-50 px-1.5 py-0.5 rounded-md"><LockClosedIcon className="w-2.5 h-2.5" /> Governance Locked</span>}
                  </div>
                </div>
                
                <div className="flex items-center gap-2">
                  {showCertificate(cr) && (
                    <button 
                      onClick={() => setSelectedReportCr(cr)}
                      className="flex items-center gap-2 px-3 py-1.5 bg-amber-50 text-amber-700 border border-amber-200 rounded-xl text-[9px] font-black uppercase hover:bg-amber-100 transition-all shadow-sm"
                    >
                      <DocumentArrowDownIcon className="w-4 h-4" /> Audit Report
                    </button>
                  )}
                  {canManage(cr) && (
                    <div className="flex items-center gap-1">
                      <button onClick={() => onEditCR(cr)} className="p-2 text-black/20 hover:text-brand-orange hover:bg-white rounded-xl transition-all"><PencilSquareIcon className="w-5 h-5" /></button>
                      <button onClick={() => { if(confirm('Purge request record?')) onDeleteCR(cr.id) }} className="p-2 text-black/20 hover:text-red-600 hover:bg-white rounded-xl transition-all"><TrashIcon className="w-5 h-5" /></button>
                    </div>
                  )}
                  <div className="text-black/10 group-hover:text-brand-orange/40 transition-colors ml-2">{STATUS_ICONS[cr.status]}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {selectedReportCr && (
        <AuditCertificate 
          cr={selectedReportCr} 
          allUsers={allUsers} 
          onClose={() => setSelectedReportCr(null)} 
        />
      )}
    </div>
  );
};

export default CRDashboard;
