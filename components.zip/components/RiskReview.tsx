
import React, { useState } from 'react';
import { 
  ShieldCheckIcon, 
  ExclamationCircleIcon, 
  ScaleIcon, 
  DocumentMagnifyingGlassIcon 
} from '@heroicons/react/24/outline';
import { ChangeRequest, CRStatus, RiskAssessment } from '../types';

interface RiskReviewProps {
  crs: ChangeRequest[];
  onAssessRisk: (crId: string, assessment: RiskAssessment) => void;
  currentUser: any;
}

const RiskReview: React.FC<RiskReviewProps> = ({ crs, onAssessRisk, currentUser }) => {
  const pendingCrs = crs.filter(cr => cr.status === CRStatus.TESTING_COMPLETED || cr.status === CRStatus.RISK_REVIEWED);
  const [selectedCr, setSelectedCr] = useState<ChangeRequest | null>(null);
  const [assessment, setAssessment] = useState<Partial<RiskAssessment>>({
    decision: 'Accept',
    operationalRisk: '',
    complianceRisk: '',
    reputationalRisk: '',
    comments: ''
  });

  const handleSubmit = () => {
    if (!selectedCr) return;
    onAssessRisk(selectedCr.id, {
      ...assessment,
      assessedBy: currentUser.name,
      timestamp: new Date().toISOString()
    } as RiskAssessment);
    setSelectedCr(null);
  };

  return (
    <div className="space-y-6 text-black">
      <header>
        <h2 className="text-3xl font-bold">Risk Assessment Portal</h2>
        <p className="text-black/60 font-medium">Reviewing completed tests for enterprise risk validation.</p>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        <div className="lg:col-span-1 space-y-4">
           <h3 className="text-sm font-bold text-black/50 uppercase tracking-widest">Awaiting Review</h3>
           {pendingCrs.map(cr => (
             <div 
              key={cr.id}
              onClick={() => setSelectedCr(cr)}
              className={`p-4 rounded-2xl border cursor-pointer transition-all ${
                selectedCr?.id === cr.id ? 'border-brand-orange bg-orange-50' : 'bg-white border-slate-200'
              }`}
             >
               <h4 className="font-bold text-black">{cr.id}</h4>
               <p className="text-xs text-black/60 line-clamp-1">{cr.title}</p>
               <div className="mt-2 flex items-center gap-1">
                 <span className="text-[10px] font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-100">Testing OK</span>
               </div>
             </div>
           ))}
           {pendingCrs.length === 0 && (
             <div className="p-8 text-center text-black/20 border border-dashed rounded-2xl">
               <p className="text-xs font-bold uppercase tracking-widest">Queue Clear</p>
             </div>
           )}
        </div>

        <div className="lg:col-span-3">
          {selectedCr ? (
            <div className="space-y-6">
              <div className="bg-white p-6 rounded-2xl border border-slate-200">
                <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
                  <DocumentMagnifyingGlassIcon className="w-5 h-5 text-brand-orange" />
                  Testing Outcomes Summary
                </h3>
                <div className="overflow-x-auto">
                  <table className="w-full text-left">
                    <thead>
                      <tr className="text-[10px] uppercase font-bold text-black/40 border-b">
                        <th className="pb-2">Feature</th>
                        <th className="pb-2">Tester</th>
                        <th className="pb-2">Result</th>
                        <th className="pb-2">Observations</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {selectedCr.features.map(f => (
                        <tr key={f.id} className="text-sm">
                          <td className="py-3 font-medium text-black">{f.name}</td>
                          <td className="py-3 text-black/70">Tester ID: {f.assignedTesterId}</td>
                          <td className="py-3">
                            <span className={`px-2 py-0.5 rounded-full font-bold text-[10px] ${
                              f.testResult === 'Pass' ? 'bg-emerald-100 text-emerald-700' : 'bg-red-100 text-red-700'
                            }`}>{f.testResult}</span>
                          </td>
                          <td className="py-3 text-black/50 italic max-w-xs truncate">{f.testObservations}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              <div className="bg-white p-8 rounded-2xl border border-slate-200 shadow-sm space-y-6">
                <h3 className="text-xl font-bold flex items-center gap-2">
                  <ShieldCheckIcon className="w-6 h-6 text-brand-orange" />
                  Risk Declaration
                </h3>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                   <div className="space-y-2">
                     <label className="text-sm font-bold flex items-center gap-1">
                       <ScaleIcon className="w-4 h-4 text-black/30" /> Operational Risk
                     </label>
                     <select 
                        className="w-full p-2 border rounded-xl outline-none focus:ring-2 focus:ring-brand-orange text-black"
                        onChange={e => setAssessment({...assessment, operationalRisk: e.target.value})}
                      >
                       <option value="">Select Level...</option>
                       <option value="Negligible">Negligible</option>
                       <option value="Acceptable">Acceptable</option>
                       <option value="High (requires mitigation)">High</option>
                     </select>
                   </div>
                   <div className="space-y-2">
                     <label className="text-sm font-bold flex items-center gap-1">
                       <ShieldCheckIcon className="w-4 h-4 text-black/30" /> Compliance Risk
                     </label>
                     <select className="w-full p-2 border rounded-xl outline-none focus:ring-2 focus:ring-brand-orange text-black" onChange={e => setAssessment({...assessment, complianceRisk: e.target.value})}>
                       <option value="">Select Level...</option>
                       <option value="Non-impactful">Non-impactful</option>
                       <option value="Aligned with CBN">Aligned with CBN</option>
                       <option value="Gap identified">Gap identified</option>
                     </select>
                   </div>
                   <div className="space-y-2">
                     <label className="text-sm font-bold flex items-center gap-1">
                       <ExclamationCircleIcon className="w-4 h-4 text-black/30" /> Risk Decision
                     </label>
                     <select 
                      className="w-full p-2 border rounded-xl bg-brand-orange text-black font-bold outline-none"
                      value={assessment.decision}
                      onChange={e => setAssessment({...assessment, decision: e.target.value as any})}
                     >
                       <option value="Accept" className="bg-white text-black">ACCEPT CHANGE</option>
                       <option value="Mitigate" className="bg-white text-black">REQUIRE MITIGATION</option>
                       {/* Reject option removed per requirements */}
                     </select>
                   </div>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-bold">Comprehensive Risk Comments</label>
                  <textarea 
                    className="w-full border rounded-2xl p-4 min-h-[120px] outline-none focus:ring-2 focus:ring-brand-orange/50 text-black font-medium"
                    placeholder="Enter final risk evaluation and mitigation strategy..."
                    value={assessment.comments}
                    onChange={e => setAssessment({...assessment, comments: e.target.value})}
                  />
                </div>

                <button 
                  onClick={handleSubmit}
                  className="w-full bg-brand-orange text-white py-4 rounded-2xl font-bold hover:bg-orange-600 shadow-xl shadow-brand-orange/30 transition-all uppercase tracking-widest text-xs"
                >
                  Finalize Risk Review
                </button>
              </div>
            </div>
          ) : (
            <div className="h-full flex flex-col items-center justify-center text-black/20 bg-white border border-slate-200 border-dashed rounded-2xl p-12 text-center">
              <ShieldCheckIcon className="w-16 h-16 mb-4 text-black/10" />
              <p className="font-bold uppercase tracking-widest text-xs">Awaiting Validation</p>
              <p className="text-[10px] font-medium text-black/40 mt-2">Select a change request from the left to perform risk validation.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default RiskReview;
