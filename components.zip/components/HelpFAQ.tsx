import React, { useState } from 'react';
import { 
  ChevronDownIcon, 
  ChevronUpIcon, 
  BookOpenIcon, 
  ShieldCheckIcon, 
  UserGroupIcon, 
  LifebuoyIcon,
  AcademicCapIcon,
  QuestionMarkCircleIcon
} from '@heroicons/react/24/outline';
import { UserRole } from '../types';

const FAQItem: React.FC<{ question: string; answer: string }> = ({ question, answer }) => {
  const [isOpen, setIsOpen] = useState(false);
  return (
    <div className="border-b border-orange-50 last:border-0">
      <button 
        onClick={() => setIsOpen(!isOpen)}
        className="w-full py-4 flex items-center justify-between text-left group"
      >
        <span className="font-bold text-black group-hover:text-brand-orange transition-colors">{question}</span>
        {isOpen ? <ChevronUpIcon className="w-5 h-5 text-brand-orange" /> : <ChevronDownIcon className="w-5 h-5 text-black/20" />}
      </button>
      {isOpen && (
        <div className="pb-4 text-sm text-black/70 animate-fadeIn font-medium">
          {answer}
        </div>
      )}
    </div>
  );
};

const HelpFAQ: React.FC = () => {
  const roles = [
    {
      role: UserRole.DB_TEAM,
      icon: <BookOpenIcon className="w-6 h-6" />,
      desc: "Initiates change requests, documents vendor versioning, and tracks the baseline setup."
    },
    {
      role: UserRole.TESTER,
      icon: <AcademicCapIcon className="w-6 h-6" />,
      desc: "Executes User Acceptance Testing (UAT), provides evidence, and certifies feature performance."
    },
    {
      role: UserRole.RISK_TEAM,
      icon: <ShieldCheckIcon className="w-6 h-6" />,
      desc: "Validates testing outcomes against operational and compliance risk frameworks."
    },
    {
      role: UserRole.HEAD_OF_IT,
      icon: <UserGroupIcon className="w-6 h-6" />,
      desc: "Provides final executive authorization for changes to enter the production environment."
    }
  ];

  const faqs = [
    {
      question: "How do I initiate a new Change Request (CR)?",
      answer: "Users with the DB Team or Admin role can click 'Initiate CR' in the sidebar. You will need to provide the vendor name, version number, and define the features that require testing."
    },
    {
      question: "I can't see any tasks in my 'My Testing' dashboard.",
      answer: "Tasks only appear if you have been specifically assigned as a tester for a feature within an active Change Request. Contact the DB Team to check your assignment status."
    },
    {
      question: "What constitutes valid testing evidence?",
      answer: "You should upload screenshots of successful transactions, system logs, or signed PDF reports. The portal supports PNG, JPG, and PDF formats up to 5MB."
    },
    {
      question: "How can I export the audit trail for a regulatory audit?",
      answer: "Administrators can access the 'Users' or 'Dashboard' views to see status distributions. For a full immutable history, use the Export CSV feature found in the Audit Trail section."
    },
    {
      question: "What happens if a change is rejected during Risk Review?",
      answer: "The change will move back to the 'Initiated' or 'Testing' stage depending on the risk team's comments. The initiator must address the gaps before re-submitting."
    }
  ];

  return (
    <div className="space-y-10 animate-fadeIn pb-20 text-black">
      <header className="border-b pb-6 border-orange-100">
        <h2 className="text-3xl font-bold">Help & Governance Resource</h2>
        <p className="text-black/60 font-medium italic">Standard Operating Procedures for Norrenpensions CMS</p>
      </header>

      {/* Workflow Section */}
      <section className="bg-white rounded-3xl p-8 border border-orange-100 shadow-sm">
        <div className="flex items-center gap-3 mb-8">
          <div className="p-2 bg-brand-orange/10 rounded-lg">
            <LifebuoyIcon className="w-6 h-6 text-brand-orange" />
          </div>
          <h3 className="text-xl font-black uppercase tracking-tight">The Change Lifecycle</h3>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-5 gap-4 relative">
          {[
            { step: "01", label: "Initiation", color: "bg-brand-navy" },
            { step: "02", label: "UAT Testing", color: "bg-brand-orange" },
            { step: "03", label: "Risk Review", color: "bg-brand-darkOrange" },
            { step: "04", label: "IT Approval", color: "bg-orange-600" },
            { step: "05", label: "Deployment", color: "bg-brand-darkBlue" },
          ].map((item, idx) => (
            <div key={idx} className="flex flex-col items-center text-center space-y-3 relative z-10">
              <div className={`w-12 h-12 ${item.color} text-white rounded-full flex items-center justify-center font-black shadow-lg`}>
                {item.step}
              </div>
              <p className="text-xs font-black uppercase tracking-widest text-black/40">{item.label}</p>
            </div>
          ))}
          {/* Connector Line */}
          <div className="hidden md:block absolute top-6 left-[10%] right-[10%] h-0.5 bg-orange-50 -z-0"></div>
        </div>
      </section>

      {/* Roles Grid */}
      <section className="space-y-6">
        <h3 className="text-sm font-black text-black/20 uppercase tracking-[0.3em] ml-1">Role Matrix & Responsibilities</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {roles.map((r, i) => (
            <div key={i} className="bg-white p-6 rounded-2xl border border-orange-100 hover:border-brand-orange transition-all group">
              <div className="w-12 h-12 bg-orange-50 rounded-xl flex items-center justify-center text-black group-hover:bg-brand-navy group-hover:text-white transition-all mb-4">
                {r.icon}
              </div>
              <h4 className="font-black text-black mb-2">{r.role}</h4>
              <p className="text-xs text-black/70 leading-relaxed font-medium">{r.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* FAQ Section */}
      <section className="bg-brand-navy rounded-3xl overflow-hidden shadow-2xl shadow-orange-950/20">
        <div className="p-8 border-b border-white/10 bg-orange-950/30">
          <h3 className="text-xl font-bold text-white uppercase tracking-tight flex items-center gap-3">
            <QuestionMarkCircleIcon className="w-6 h-6 text-brand-orange" />
            Frequently Asked Questions
          </h3>
        </div>
        <div className="bg-white p-8">
          <div className="divide-y divide-orange-50">
            {faqs.map((faq, i) => (
              <FAQItem key={i} question={faq.question} answer={faq.answer} />
            ))}
          </div>
        </div>
      </section>

      {/* Support Footer */}
      <footer className="bg-orange-50/30 rounded-2xl p-6 border text-center border-orange-100">
        <p className="text-sm text-black/70 font-bold">
          Still have questions? Contact the <span className="font-black underline decoration-brand-orange underline-offset-4">Norrenpensions ICT Support Team</span> at <a href="mailto:ict@norrenpensions.com" className="text-brand-orange font-black">ict@norrenpensions.com</a>
        </p>
      </footer>
    </div>
  );
};

export default HelpFAQ;