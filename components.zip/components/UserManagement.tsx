
import React, { useState, useRef } from 'react';
import { 
  PlusIcon, 
  UserIcon, 
  EnvelopeIcon, 
  PhoneIcon, 
  TrashIcon, 
  PencilSquareIcon, 
  XMarkIcon, 
  NoSymbolIcon, 
  CheckIcon,
  PencilIcon
} from '@heroicons/react/24/outline';
import { User, UserRole } from '../types';

interface UserManagementProps {
  users: User[];
  currentUser: User;
  onAddUser: (user: User) => void;
  onUpdateUser: (user: User) => void;
  onDeleteUser: (id: string) => void;
}

const UserManagement: React.FC<UserManagementProps> = ({ users, currentUser, onAddUser, onUpdateUser, onDeleteUser }) => {
  const [showForm, setShowForm] = useState(false);
  const [editingUser, setEditingUser] = useState<User | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [formData, setFormData] = useState({
    name: '',
    roles: [] as UserRole[],
    unit: '',
    email: '',
    phone: '',
    signature: ''
  });

  const isAuthorizedManager = currentUser.roles.includes(UserRole.ADMIN) || currentUser.roles.includes(UserRole.DB_TEAM);

  const displayedUsers = isAuthorizedManager 
    ? users 
    : users.filter(u => u.id === currentUser.id);

  const toggleRole = (role: UserRole) => {
    setFormData(prev => ({
      ...prev,
      roles: prev.roles.includes(role) 
        ? prev.roles.filter(r => r !== role) 
        : [...prev.roles, role]
    }));
  };

  const handleSignatureUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setFormData(prev => ({ ...prev, signature: reader.result as string }));
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (formData.roles.length === 0) {
      alert("At least one role must be selected.");
      return;
    }

    if (editingUser) {
      onUpdateUser({
        ...editingUser,
        name: formData.name,
        roles: formData.roles,
        unit: formData.unit,
        email: formData.email,
        phone: formData.phone,
        signature: formData.signature
      });
    } else if (isAuthorizedManager) {
      const user: User = {
        id: `u-${Date.now()}`,
        name: formData.name,
        roles: formData.roles,
        unit: formData.unit,
        email: formData.email,
        phone: formData.phone,
        status: 'active',
        signature: formData.signature
      };
      onAddUser(user);
    }
    resetForm();
  };

  const toggleStatus = (user: User) => {
    if (!isAuthorizedManager) return;
    onUpdateUser({
      ...user,
      status: user.status === 'disabled' ? 'active' : 'disabled'
    });
  };

  const resetForm = () => {
    setShowForm(false);
    setEditingUser(null);
    setFormData({ name: '', roles: [], unit: '', email: '', phone: '', signature: '' });
  };

  const startEditing = (user: User) => {
    setEditingUser(user);
    setFormData({
      name: user.name,
      roles: user.roles,
      unit: user.unit || '',
      email: user.email,
      phone: user.phone,
      signature: user.signature || ''
    });
    setShowForm(true);
  };

  const isEditingSelf = editingUser?.id === currentUser.id;

  return (
    <div className="space-y-6 animate-fadeIn text-black">
      <header className="flex justify-between items-center border-b pb-6 border-orange-100">
        <div>
          <h2 className="text-3xl font-bold">{isAuthorizedManager ? 'User Registry' : 'My Staff Profile'}</h2>
          <p className="text-black/60 font-medium italic">
            {isAuthorizedManager 
              ? 'Personnel authorized for Norrenpensions change governance.' 
              : 'View and update your official personnel records.'}
          </p>
        </div>
        {isAuthorizedManager && (
          <button 
            onClick={() => {
              if (showForm) resetForm();
              else setShowForm(true);
            }}
            className={`px-4 py-2 rounded-xl flex items-center gap-2 transition-all font-black shadow-sm ${
              showForm ? 'bg-slate-200 text-black' : 'bg-brand-orange text-white hover:bg-orange-600 shadow-brand-orange/20'
            }`}
          >
            {showForm ? <XMarkIcon className="w-5 h-5" /> : <PlusIcon className="w-5 h-5" />}
            {showForm ? 'Cancel Action' : 'Register New Personnel'}
          </button>
        )}
      </header>

      {showForm && (
        <form onSubmit={handleSubmit} className="bg-white p-8 rounded-3xl border border-brand-orange/20 shadow-xl animate-fadeIn space-y-6">
          <h3 className="text-lg font-bold">
            {editingUser ? (isEditingSelf ? 'Update Your Profile' : `Update Details for ${editingUser.name}`) : 'Register New Personnel'}
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="space-y-6">
              <div className="space-y-1">
                <label className="text-[10px] font-black text-black/40 uppercase tracking-widest ml-1">Full Name</label>
                <input 
                  required
                  className="w-full border-2 border-slate-100 p-3 rounded-2xl outline-none focus:border-brand-orange text-black font-bold"
                  placeholder="John Doe"
                  value={formData.name}
                  onChange={e => setFormData({...formData, name: e.target.value})}
                />
              </div>
              <div className="space-y-1">
                <label className="text-[10px] font-black text-black/40 uppercase tracking-widest ml-1">Email Address</label>
                <input 
                  type="email"
                  required
                  disabled={isEditingSelf && !isAuthorizedManager}
                  className={`w-full border-2 border-slate-100 p-3 rounded-2xl outline-none focus:border-brand-orange text-black font-bold ${isEditingSelf && !isAuthorizedManager ? 'bg-slate-50 opacity-60' : ''}`}
                  placeholder="staff.name@norrenpensions.com"
                  value={formData.email}
                  onChange={e => setFormData({...formData, email: e.target.value})}
                />
              </div>
              <div className="space-y-1">
                <label className="text-[10px] font-black text-black/40 uppercase tracking-widest ml-1">Phone Number</label>
                <input 
                  required
                  className="w-full border-2 border-slate-100 p-3 rounded-2xl outline-none focus:border-brand-orange text-black font-bold"
                  placeholder="+234..."
                  value={formData.phone}
                  onChange={e => setFormData({...formData, phone: e.target.value})}
                />
              </div>
            </div>

            <div className="space-y-6">
              <div className="space-y-1">
                <label className="text-[10px] font-black text-black/40 uppercase tracking-widest ml-1">Business Unit</label>
                <input 
                  required
                  className="w-full border-2 border-slate-100 p-3 rounded-2xl outline-none focus:border-brand-orange text-black font-bold"
                  placeholder="e.g., Operations, Finance"
                  value={formData.unit}
                  onChange={e => setFormData({...formData, unit: e.target.value})}
                />
              </div>
              <div className="space-y-1">
                <label className="text-[10px] font-black text-black/40 uppercase tracking-widest ml-1">Governance Signature</label>
                <div 
                  onClick={() => fileInputRef.current?.click()}
                  className="w-full h-32 border-2 border-dashed border-slate-200 rounded-2xl bg-slate-50 flex items-center justify-center cursor-pointer hover:bg-orange-50/30 transition-all overflow-hidden relative group"
                >
                  {formData.signature ? (
                    <>
                      <img src={formData.signature} alt="Signature" className="h-full object-contain mix-blend-multiply" />
                      <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                         <PencilIcon className="w-6 h-6 text-white" />
                      </div>
                    </>
                  ) : (
                    <div className="text-center p-4">
                      <PencilIcon className="w-6 h-6 text-black/20 mx-auto mb-2" />
                      <p className="text-[10px] font-black text-black/40 uppercase tracking-widest">Click to upload e-signature</p>
                    </div>
                  )}
                  <input 
                    type="file" 
                    ref={fileInputRef} 
                    className="hidden" 
                    accept="image/*" 
                    onChange={handleSignatureUpload} 
                  />
                </div>
              </div>
            </div>

            <div className="md:col-span-2 space-y-3">
              <label className="text-[10px] font-black text-black/40 uppercase tracking-widest ml-1">System Roles (Multi-Select)</label>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                {Object.values(UserRole).map(role => (
                  <button
                    key={role}
                    type="button"
                    disabled={!isAuthorizedManager}
                    onClick={() => toggleRole(role)}
                    className={`px-4 py-2.5 rounded-xl border text-[10px] font-black transition-all ${
                      formData.roles.includes(role)
                        ? 'bg-brand-orange text-white border-brand-orange shadow-lg shadow-orange-900/20'
                        : 'bg-white text-black/40 border-slate-200 hover:border-brand-orange/40'
                    }`}
                  >
                    {role.toUpperCase()}
                  </button>
                ))}
              </div>
            </div>
          </div>
          <div className="flex justify-end pt-4 gap-4">
             <button 
                type="button" 
                onClick={resetForm}
                className="px-8 py-3 rounded-2xl font-black text-xs uppercase tracking-widest text-black/40 hover:bg-slate-100 transition-all"
             >
                Cancel
             </button>
             <button type="submit" className="bg-brand-orange text-white px-10 py-3 rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl shadow-brand-orange/20 hover:bg-orange-600 transition-all">
               {editingUser ? 'Save Updates' : 'Register Personnel'}
             </button>
          </div>
        </form>
      )}

      <div className="bg-white rounded-[2rem] border border-slate-200 overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead className="bg-slate-50 border-b">
              <tr className="text-[10px] uppercase font-black text-black/30 tracking-widest">
                <th className="px-6 py-4">Registry Identity</th>
                <th className="px-6 py-4">Authorization Roles</th>
                <th className="px-6 py-4">Verification</th>
                <th className="px-6 py-4">Status</th>
                <th className="px-6 py-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {displayedUsers.map(u => (
                <tr key={u.id} className={`hover:bg-slate-50 transition-colors ${u.status === 'disabled' ? 'bg-slate-50 opacity-60' : ''}`}>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-brand-orange/10 flex items-center justify-center text-brand-orange border border-brand-orange/20 font-black">
                        {u.name.charAt(0)}
                      </div>
                      <div>
                        <p className={`font-black text-black ${u.status === 'disabled' ? 'line-through' : ''}`}>
                          {u.name} {u.id === currentUser.id && <span className="text-[9px] bg-brand-orange text-white px-1.5 py-0.5 rounded-md ml-1 uppercase font-black">Me</span>}
                        </p>
                        <p className="text-[9px] text-black/30 font-mono">{u.email}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                     <div className="flex flex-wrap gap-1">
                       {u.roles.map(role => (
                         <span key={role} className="px-2 py-0.5 bg-orange-50 text-brand-orange text-[8px] font-black rounded-md border border-orange-100 uppercase tracking-tighter">
                           {role}
                         </span>
                       ))}
                     </div>
                     <p className="text-xs text-black/60 font-bold mt-1">{u.unit || 'General'}</p>
                  </td>
                  <td className="px-6 py-4">
                     {u.signature ? (
                       <div className="w-16 h-8 bg-slate-50 rounded-lg overflow-hidden border border-slate-100 flex items-center justify-center p-1">
                          <img src={u.signature} alt="Sig" className="h-full object-contain mix-blend-multiply opacity-60 grayscale" />
                       </div>
                     ) : (
                       <span className="text-[8px] font-black text-black/20 uppercase">No Sig Captured</span>
                     )}
                  </td>
                  <td className="px-6 py-4">
                     {u.status === 'disabled' ? (
                       <span className="inline-flex items-center gap-1 text-[9px] font-black text-red-600 bg-red-50 px-2 py-0.5 rounded-full border border-red-100">
                         <NoSymbolIcon className="w-3 h-3" /> DEACTIVATED
                       </span>
                     ) : (
                       <span className="inline-flex items-center gap-1 text-[9px] font-black text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-100">
                         <CheckIcon className="w-3 h-3" /> ACTIVE
                       </span>
                     )}
                  </td>
                  <td className="px-6 py-4 text-right">
                    <div className="flex justify-end gap-2">
                       {(isAuthorizedManager || u.id === currentUser.id) && (
                         <button onClick={() => startEditing(u)} className="p-2 text-black/20 hover:text-brand-orange hover:bg-orange-50 rounded-xl transition-all">
                           <PencilSquareIcon className="w-5 h-5" />
                         </button>
                       )}
                       {isAuthorizedManager && u.id !== currentUser.id && (
                         <>
                           <button onClick={() => toggleStatus(u)} className={`p-2 rounded-xl transition-all ${u.status === 'disabled' ? 'text-emerald-500 hover:bg-emerald-50' : 'text-amber-500 hover:bg-amber-50'}`}>
                             {u.status === 'disabled' ? <CheckIcon className="w-5 h-5" /> : <NoSymbolIcon className="w-5 h-5" />}
                           </button>
                           <button onClick={() => { if(confirm('Purge user records?')) onDeleteUser(u.id) }} className="p-2 text-black/20 hover:text-red-600 hover:bg-red-50 rounded-xl transition-all">
                             <TrashIcon className="w-5 h-5" />
                           </button>
                         </>
                       )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default UserManagement;
