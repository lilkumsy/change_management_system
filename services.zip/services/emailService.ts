
/**
 * SECURE MAIL BRIDGE SERVICE (v2.5.1)
 * 
 * Optimized for Office365 SMTP relay via SmtpJS.
 */

export interface MailRequest {
  to: string;
  subject: string;
  body: string;
  templateId?: string;
}

declare global {
  interface Window {
    Email: {
      send: (config: any) => Promise<string>;
    };
  }
}

export class EmailService {
  private static readonly BACKEND_RELAY_URL = '/api/v1/notifications/dispatch';
  private static readonly CLIENT_BRIDGE_KEY = 'NPL-CMS-RELAY-SECURE-2024';

  /**
   * Dispatches email via the most secure available channel.
   */
  static async sendEmail(to: string, subject: string, body: string): Promise<{ success: boolean; messageId: string }> {
    console.log(`[MailBridge] Dispatching to: ${to}`);

    try {
      // 1. ATTEMPT SECURE BACKEND RELAY (Production Architecture)
      const response = await this.dispatchViaBackend({ to, subject, body });
      if (response.success) return response;

      // 2. FALLBACK TO DIRECT RELAY (For Testing/Preview)
      return await this.dispatchViaDirectRelay(to, subject, body);

    } catch (error) {
      const errorMsg = error instanceof Error ? error.message : 'Unknown SMTP Error';
      console.error(`[MailBridge] Fatal Error:`, errorMsg);
      throw new Error(errorMsg);
    }
  }

  private static async dispatchViaBackend(data: MailRequest) {
    try {
      const resp = await fetch(this.BACKEND_RELAY_URL, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${this.CLIENT_BRIDGE_KEY}`
        },
        body: JSON.stringify(data)
      });

      if (resp.ok) {
        const result = await resp.json();
        return { success: true, messageId: result.id };
      }
      return { success: false, messageId: '' };
    } catch {
      return { success: false, messageId: '' };
    }
  }

  /**
   * Direct Relay using SmtpJS + Office365
   * Note: Office365 requires Port 587 and SMTP AUTH enabled on the account.
   */
  private static async dispatchViaDirectRelay(to: string, subject: string, body: string) {
    if (!window.Email) {
      console.warn("[MailBridge] SMTP Library missing. Falling back to console logging.");
      console.log("MOCK EMAIL TO:", to, "SUBJECT:", subject);
      return { success: true, messageId: `mock-${Date.now()}` };
    }

    const config = {
      Host: 'smtp.office365.com',
      Username: 'noreply-npl@norrenpensions.com',
      Password: 'G3n3r@l.comm',
      To: to,
      From: 'noreply-npl@norrenpensions.com',
      Subject: subject,
      Body: body,
      Port: 587 // Explicitly required for O365 TLS
    };

    console.debug('[MailBridge] Relay Configuration:', { ...config, Password: '***' });

    const relayResponse = await window.Email.send(config);

    // SmtpJS returns "OK" on success, or a descriptive error string on failure
    if (relayResponse === 'OK') {
      console.log(`[MailBridge] Success: Message sent to ${to}`);
      return { success: true, messageId: `relay-o365-${Date.now()}` };
    } else {
      // If Office365 rejects, this string usually contains "Authentication Failed" 
      // or "The SMTP server requires a secure connection"
      throw new Error(relayResponse);
    }
  }
}
