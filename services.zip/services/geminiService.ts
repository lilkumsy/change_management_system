import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export async function draftNotificationEmail(userName: string, crId: string, featureName: string) {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Draft a professional banking notification email for ${userName} regarding a new test assignment.
      Change Request ID: ${crId}
      Feature: ${featureName}
      Return a JSON object with:
      - subject: A clear subject line including the CR ID.
      - body: The HTML body of the email. Keep it professional with Norrenpensions branding context.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            subject: { type: Type.STRING },
            body: { type: Type.STRING }
          },
          required: ["subject", "body"]
        }
      }
    });
    
    return JSON.parse(response.text);
  } catch (error) {
    console.error("Error drafting email:", error);
    return {
      subject: `Assigned: Testing Task for ${crId}`,
      body: `<p>Dear ${userName},</p><p>You have been assigned to test the feature: <strong>${featureName}</strong> for Change Request <strong>${crId}</strong>.</p>`
    };
  }
}