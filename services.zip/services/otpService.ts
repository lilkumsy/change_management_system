// OTP Service for generating and sending one-time passwords via Office365 email
// In-app notification is also created (simple in-memory store)

import { EmailService } from "./emailService";
import { AppNotification } from "../types";

// Simple in-memory notification store (could be replaced with a proper store later)
const inAppNotifications: AppNotification[] = [];

/**
 * Generates a numeric OTP of given length.
 * @param length Number of digits for the OTP (default 6)
 */
export function generateOtp(length: number = 6): string {
    const min = Math.pow(10, length - 1);
    const max = Math.pow(10, length) - 1;
    // Using crypto for better randomness if available
    if (typeof crypto !== "undefined" && crypto.getRandomValues) {
        const array = new Uint32Array(1);
        crypto.getRandomValues(array);
        const random = array[0] / (0xffffffff + 1);
        return Math.floor(min + random * (max - min + 1)).toString();
    }
    // Fallback to Math.random
    return Math.floor(min + Math.random() * (max - min + 1)).toString();
}

/**
 * Sends an OTP email using Office365 SMTP relay.
 * @param to Recipient email address
 * @param userId Identifier of the user (used for in‑app notification)
 * @returns The generated OTP string
 */
export async function sendOtpEmail(to: string, userId: string): Promise<string> {
    const otp = generateOtp();
    const subject = `Your One‑Time Password (OTP)`;
    const body = `
    <p>Hello,</p>
    <p>Your one‑time password is: <strong>${otp}</strong></p>
    <p>This code will expire in 5 minutes. Please do not share it with anyone.</p>
    <p>Thank you,</p>
    <p>Norrenpensions Team</p>
  `;

    // Log OTP for local development testing
    console.log(`[DEV MODE] OTP Generated for ${to}:`, otp);

    // Use the direct O365 relay defined in EmailService
    // Wrap in try/catch to prevent SMTP Auth failures from completely blocking the testing flow
    try {
        await EmailService.sendEmail(to, subject, body);
    } catch (error) {
        console.error("[OTP Service] Non-fatal email delivery failure:", error);
    }

    // Create an in‑app notification for the user
    const notification: AppNotification = {
        id: crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random()}`,
        userId,
        title: "OTP Sent",
        message: `An OTP has been sent to ${to}.`,
        timestamp: new Date().toISOString(),
        read: false,
        type: "alert",
    };
    inAppNotifications.push(notification);

    return otp;
}

/**
 * Retrieves all in‑app notifications for a given user.
 * @param userId User identifier
 * @returns Array of AppNotification objects
 */
export function getUserNotifications(userId: string): AppNotification[] {
    return inAppNotifications.filter((n) => n.userId === userId);
}

/**
 * Marks a notification as read.
 * @param notificationId ID of the notification to mark
 */
export function markNotificationRead(notificationId: string): void {
    const notif = inAppNotifications.find((n) => n.id === notificationId);
    if (notif) {
        notif.read = true;
    }
}
